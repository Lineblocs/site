<?php

use Illuminate\Database\Seeder;

class AddFlowsTemplates extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
