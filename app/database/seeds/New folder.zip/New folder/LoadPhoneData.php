<?php

use Illuminate\Database\Seeder;

class LoadPhoneData extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //

        /*
        \DB::unprepared(file_get_contents(base_path('sql-backups/phone-defs-grandstreams.sql')));
        require_once(base_path('phones_defaults_cisco.php'));
        require_once(base_path('phones_defaults_polycomIP330.php'));
        */
    }
}
