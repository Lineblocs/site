const awsServerlessExpress = require('aws-serverless-express')
const app = require('./app')
const server = awsServerlessExpress.createServer(app)

var event = {
  "version": "2.0",
  "routeKey": "ANY /{proxy+}",
  "rawPath": "/prod/anecweb-api/book/1",
  "rawQueryString": "",
  "headers": {
    "accept": "*/*",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-US,en;q=0.9",
    "cache-control": "no-cache",
    "content-length": "107",
    "content-type": "application/json",
    "host": "4gmhhyk418.execute-api.eu-central-1.amazonaws.com",
    "origin": "chrome-extension://fhbjgbiflinjbdggehcddcbncdddomop",
    "postman-token": "13025618-a216-f584-2b55-20402e935b3f",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "none",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36",
    "x-amzn-trace-id": "Root=1-600f2ab5-3b12ecea14837140472a85e5",
    "x-forwarded-for": "68.148.172.89",
    "x-forwarded-port": "443",
    "x-forwarded-proto": "https"
  },
  "requestContext": {
    "accountId": "860952457104",
    "apiId": "4gmhhyk418",
    "domainName": "4gmhhyk418.execute-api.eu-central-1.amazonaws.com",
    "domainPrefix": "4gmhhyk418",
    "http": {
      "method": "GET",
      "path": "/prod/anecweb-api/book/1",
      "protocol": "HTTP/1.1",
      "sourceIp": "68.148.172.89",
      "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36"
    },
    "requestId": "ZuOcUgKGliAEM1w=",
    "routeKey": "ANY /{proxy+}",
    "stage": "prod",
    "time": "25/Jan/2021:20:31:49 +0000",
    "timeEpoch": 1611606709136
  },
  "pathParameters": {
    "proxy": "anecweb-api/tags?book_id=1"
  },
  "body": "{\"cognito_id\": \"123\", \n\t\"first_name\": \"Test 123\",\n\t\t\"last_name\": \"Test 123\",\n\t\t\t\"email\": \"test@example.org\",\n\t\t\t\t\"locale\": \"1\"\n}",
  "isBase64Encoded": false
};
var context = {
	succeed: function() {
		console.log(arguments);
	}
};
console.log("Got request..");
console.log(`EVENT: ${JSON.stringify(event)}`);
var path  = event['rawPath'];
path = path.replace(/^\/prod/, "");
path = path.replace(/^\/dev/, "");
path = path.replace(/^\/staging/, "");
path = path.replace(/^\/anecweb-api/, "");
event['path'] = path;
event['httpMethod'] = event.requestContext.http.method;
awsServerlessExpress.proxy(server, event, context)
