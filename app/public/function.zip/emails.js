var TEMPLATES = {
  'new-invited': {
      subject: 'Anecdobio - You have been invited.',
      body: `
You have been invited to book: {book_name}. To login please use the following credentials:

{email}
{password}

Thanks,
Anecdobio team
`
  },
  'exist-invited': {
      subject: 'Anecdobio - You have been invited.',
      body: `
You have been added to book: {book_name}. This book should now appear in your dashboard.

Thanks,
Anecdobio team 
`
  }
};

module.exports = {
  TEMPLATES
};
