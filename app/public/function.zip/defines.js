var QUESTION_TYPES = {
  "SYSTEM": "1",
  "CUSTOM": "2"
};
var ROLE_TYPES = {
  "WRITER": "1",
  "READER": "2"
};
var ROLE_LINK_TYPES = {
  "BOOK": "6",
  "ANSWER": "7",
  "BOOK_JOIN": "7"
};

module.exports = {
  QUESTION_TYPES,
  ROLE_LINK_TYPES,
  ROLE_TYPES
};
