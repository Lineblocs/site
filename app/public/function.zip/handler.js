// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const awsServerlessExpress = require('aws-serverless-express')
const app = require('./app')
const server = awsServerlessExpress.createServer(app)

exports.handler = (event, context, callback) => { 
    console.log("Got request..");
    console.log(`EVENT: ${JSON.stringify(event)}`);
    var path  = event['rawPath'];
    path = path.replace(/^\/prod/, "");
    path = path.replace(/^\/dev/, "");
    path = path.replace(/^\/staging/, "");
    path = path.replace(/^\/anecweb-api/, "");
    event['path'] = path;
    event['httpMethod'] = event.requestContext.http.method;
    awsServerlessExpress.proxy(server, event, context) };