// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const { executeReadSql, executeWriteSql } = require('./utils')
const fetchLocales= async () => {
  let sql = 'SELECT * FROM locale';
  const parameters = [
  ];

  const result = await executeReadSql(sql, parameters)
  return result
}

module.exports = {
  fetchLocales,
}