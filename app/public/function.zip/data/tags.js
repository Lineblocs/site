// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const { executeReadSql, executeWriteSql } = require('./utils')

const fetchTags = async (book_id) => {
  const parameters = [
    {
      name: 'book_id',
      value: { longValue: book_id}
    }
  ];
  let sql = `select question.question_id, question.dsply_text, group_concat(tag.name,':',tag.color) as tags, ifnull(book_question_join.book_question_join_id,"Not Assigned") as status from book
inner join question on book.locale_id=question.locale_id and question.is_retired=0 and question.question_type_id=1
left join question_tag_join on question.question_id=question_tag_join.question_id and question_tag_join.is_retired=0
left join tag on tag.tag_id=question_tag_join.tag_id
left join book_question_join on book_question_join.book_id=book.book_id and book_question_join.question_id=question.question_id and book_question_join.is_retired=0
where book.book_id=:book_id
group by question.question_id;
`;
  console.log("query is: " , sql);
  const result = await executeReadSql(sql, parameters)
  return result
}

const fetchTagQuestions = async (tag_id) => {
  const parameters = [
    {
      name: 'book_id',
      value: { longValue: book_id}
    },
    {
      name: 'tag_id',
      value: { longValue: tag_id}
    },

  ];
  let sql = `select question.dsply_text, group_concat(tag.name,':',tag.color) as tags, ifnull(book_question_join.book_question_join_id,"Not Assigned") as status from book
inner join question on book.locale_id=question.locale_id and question.is_retired=0 and question.question_type_id=1
left join question_tag_join on question.question_id=question_tag_join.question_id and question_tag_join.is_retired=0
left join tag on tag.tag_id=question_tag_join.tag_id
left join book_question_join on book_question_join.book_id=book.book_id and book_question_join.question_id=question.question_id and book_question_join.is_retired=0
where book.book_id=:book_id
and tag.tag_id=:tag_id
group by question.question_id;
`;
/*
  let sql = 'SELECT tag.*, question.* FROM book';
  sql += ' INNER JOIN question_tag_join ON question_tag_join.tag_id = tag.tag_id';
  sql += ' INNER JOIN question ON question.question_id = question_tag_join.question_id ';
  sql += ' INNER JOIN book_question_join ON book_question_join.question_id = question.question_id ';
  sql += ' INNER JOIN book ON book.book_id = book_question_join.book_id ';
  sql +=  'WHERE tag.tag_id = :tag_id ';
  sql +=  'AND question.type_id = "SYSTEM" ';
  sql +=  'AND book.locale_id = question.locale_id';
  */
  console.log("query is: " , sql);
  const result = await executeReadSql(sql, parameters)
  return result
}
module.exports = {
  fetchTags,
  fetchTagQuestions
}