// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const AWS = require('aws-sdk')
const jwt = require('jsonwebtoken');
const jwkToPem = require('jwk-to-pem');
const { resolve } = require('path');
const rdsdataservice = new AWS.RDSDataService();

const parseRecords = (records, columnMetadata) => {
  // Format the results into key-value pairs with the column name and value
console.log("parsing records ",records);
  const parsed = records.map((result) => {
    const obj = {}
    result.forEach((elem, idx) => {
      const columnName = columnMetadata[idx].name
      const [ columnValue, ]= Object.values(elem)
      obj[columnName] = columnValue
    })
    return obj
  })
  return parsed

}

const executeReadSql = async (sql, parameters) => {
	console.log("execute read params ", parameters);
  const params = {
    resourceArn: process.env.DATABASE_ARN,
    secretArn: process.env.SECRET_ARN,
    database: 'web',
    includeResultMetadata: true,
    sql
  }
  if (parameters) {
    params.parameters = parameters
  }
  const rawResults = await rdsdataservice.executeStatement(params).promise()
  let results = []
  if (rawResults.records) {
    results = parseRecords(rawResults.records, rawResults.columnMetadata)
  }
  return results
}

const executeWriteSql = async (sql, parameters) => {
  const params = {
    resourceArn: process.env.DATABASE_ARN,
    secretArn: process.env.SECRET_ARN,
    database: 'web',
    includeResultMetadata: true,
    sql
  }
  if (parameters) {
    params.parameters = parameters
  }
  return await rdsdataservice.executeStatement(params).promise()
}

const decodeJWT = async function(req) {
  var auth =  req.headers('Authorization');
  var splitted = auth.split(" ");
  var token = splitted[1];
  return new Promise(function(resolve, reject) {
    var pem = jwkToPem(jwk);
    jwt.verify(token, pem, function(err, decoded) {
      console.log(decoded)
      resolve( decoded );
    }, function(err) {
      reject( err );
    });
  });
}

async function estimatePages(book)
{
  return new Promise((resolve, reject) => {
    resolve(0);
  })
}

function createS3Client() {
  // Set the region
  AWS.config.update({region: 'eu-central-1'});

  // Create S3 service object
  s3 = new AWS.S3({apiVersion: '2006-03-01'});
  return s3;

}
function createSESClient() {
  // Set the region
  AWS.config.update({region: 'eu-west-1'});

  // Create S3 service object
  var ses = new AWS.SES({apiVersion: '2010-12-01'});
  return ses;

}
module.exports = {
  executeReadSql,
  executeWriteSql,
  decodeJWT,
  createS3Client,
  createSESClient
}
