// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const { executeReadSql, executeWriteSql } = require('./utils')

const addUser = async (cognito_id, email, first_name, last_name, locale) => {
  const sql = `INSERT INTO user (cognito_id, email, first_name, last_name, locale_id) \
VALUES (:cognito_id, :email, :first_name, :last_name, :locale_id)`
const  parameters = [
    {
      name: 'cognito_id',
      value: { stringValue: cognito_id }
    },
    {
      name: 'email',
      value: { stringValue: email}
    },
    {
      name: 'first_name',
      value: { stringValue: first_name}
    },
    {
      name: 'last_name',
      value: { stringValue: last_name}
    },
    {
      name: 'locale_id',
      value: { stringValue: locale}
    }
  ]
  const result = await executeWriteSql(sql, parameters)
  return result;
 
}

const fetchUserByEmail= async (email) => {
  let sql = 'SELECT * FROM user WHERE email = :email';
  const parameters = [
    {
      name: 'email',
      value: { stringValue: email}
    }
  ];

  const result = await executeReadSql(sql, parameters)
  return result
}

const fetchUserByCognitoID= async (id) => {
  let sql = 'SELECT * FROM user WHERE cognito_id = :id';
  const parameters = [
    {
      name: 'id',
      value: { stringValue: id}
    }
  ];

	console.log("query params ", parameters);
  const result = await executeReadSql(sql, parameters)
	console.log("user result is ", result);
  return result[0];
}
module.exports = {
  addUser,
  fetchUserByEmail,
  fetchUserByCognitoID
};
