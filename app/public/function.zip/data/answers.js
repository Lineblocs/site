// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const { executeReadSql, executeWriteSql } = require('./utils')
const createAnswer = async (book_question_join_id, user_id, answer_text) => {
  const parameters = [
    {
      name: 'book_question_join_id',
      value: { longValue: book_question_join_id }
    },

    {
      name: 'user_id',
      value: { longValue: user_id }
    },
    {
      name: 'answer_text',
      value: { stringValue: answer_text}
    },
  ]
  const sql = 'INSERT INTO answers (book_question_join_id, user_id, answer_text) \
  VALUES (:book_question_join_id, :user_id, :answer_text)';
  const result = await executeWriteSql(sql, parameters)
  return result
}
const updateAnswer = async (answer_id, answer_text) => {
  const parameters = [
    {
      name: 'answer_id',
      value: { longValue: answer_id }
    },
    {
      name: 'answer_text',
      value: { stringValue: answer_text}
    }
  ]
  const sql = 'UPDATE answers SET answer_text = :answer_text WHERE answer_id = :answer_id';
  const result = await executeWriteSql(sql, parameters)
  return result
}
const fetchAnswer = async (answer_id) => {
  const parameters = [
    {
      name: 'answer_id',
      value: { longValue: answer_id }
    }
  ]
  const sql = 'SELECT question.title, question.dsply_text, answers.answer_text, answers.last_modified_datetime, CONCAT(user.first_name, " ", user.last_name) AS fullname FROM answers \
  INNER JOIN question ON question.question_id= answer.question_id \
  INNER JOIN user ON user.user_id=answer.user_id \
  WHERE answer.answer_id = :answer_id'
  const result = await executeReadSql(sql, parameters)
  return result
}
const fetchUserAnswer = async (user_id, question_id) => {
  const parameters = [
    {
      name: 'user_id',
      value: { longValue: user_id }
    },
    {
      name: 'question_id',
      value: { longValue: question_id}
    }
  ]
  const sql = 'SELECT question.title, question.dsply_text, answers.answer_text, answers.last_modified_datetime, CONCAT(user.first_name, " ", user.last_name) AS fullname FROM answers \
  INNER JOIN book_question_join ON book_question_join.question_id= answer.question_id \
  INNER JOIN question ON question.question_id= answer.question_id \
  INNER JOIN user ON user.user_id=answer.user_id \
  WHERE user.user_id = :user_id and question.question_id = :question_id'
  const result = await executeReadSql(sql, parameters)
  return result
}
const fetchUserAnswers = async (user_id, question_id) => {
  const parameters = [
    {
      name: 'user_id',
      value: { longValue: user_id }
    }
  ]
  const sql = 'SELECT question.title, question.dsply_text, answers.answer_text, answers.last_modified_datetime, CONCAT(user.first_name, " ", user.last_name) AS fullname FROM answers \
  INNER JOIN question ON question.question_id= answer.question_id \
  INNER JOIN user ON user.user_id=answer.user_id \
  WHERE user.user_id = :user_id'
  const result = await executeReadSql(sql, parameters)
  return result
}
const fetchBookAnswers = async (user_id, book_id) => {
  const parameters = [
    {
      name: 'book_id',
      value: { longValue: book_id}
    }
  ]
  const sql = 'SELECT question.title, question.dsply_text, answers.answer_text, answers.last_modified_datetime, CONCAT(user.first_name, " ", user.last_name) AS fullname FROM answers \
  INNER JOIN question ON question.question_id= answer.question_id \
  INNER JOIN user ON user.user_id=answer.user_id \
  WHERE answer.book_id = :book_id'
  const result = await executeReadSql(sql, parameters)
  return result
}

const fetchQuestionAnswers = async (user_id, question_id) => {
  const parameters = [
    {
      name: 'question_id',
      value: { longValue: question_id}
    }
  ]
  const sql = 'SELECT question.title, question.dsply_text, answers.answer_text, answers.last_modified_datetime, CONCAT(user.first_name, " ", user.last_name) AS fullname FROM answers \
  INNER JOIN question ON question.question_id= answer.question_id \
  INNER JOIN user ON user.user_id=answer.user_id \
  WHERE answer.question_id = :question_id'
  const result = await executeReadSql(sql, parameters)
  return result
}

module.exports = { 
  createAnswer,
  updateAnswer,
  fetchUserAnswers,
  fetchQuestionAnswers,
  fetchBookAnswers
};
