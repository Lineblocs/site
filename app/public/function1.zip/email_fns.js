const { fetchEmail  } = require('./data/emails')

const { fetchUsers, fetchUser } = require('./data/users.js')
const { fetchAllBooks, fetchAllBookQuestions, fetchBookQuestions, updateBookQuestion, updateBook, fetchBooksThatRequirePublish } = require('./data/books.js')
const {createEmailTemplate, replaceTemplatePlaceholders, sendEmail, calculateSendDate } = require('./data/utils')
const moment = require('moment');
const { fetchUserByCognitoID } = require('./data/users');

var EMAILS = {

}
function sent_welcome_email( book ) {
	console.log("checking book ", book);
	console.log("welcome sent: " + book.welcome_sent.toString());
    if ( book.welcome_sent === 1 ) {
        return true;
    }
    return false;
}

async function processWelcome() {
    return new Promise(async (resolve, reject) => {
        var books = await fetchAllBooks();
        for (var index in books) {
		try {
            var book = books[ index ];
console.log("Processing book: " + book.book_id);
            if ( !sent_welcome_email( book ) ) {
                var template =await fetchEmail("welcome", book.locale_id);
console.log("found template ", template);
                var user = await fetchUser( book.purchaser_user_id );
		    console.log("purchasing user ", user);
                var replacements = {
                    "purchaserFirstName": user.first_name,
                    "welcomeMessage": book.welcome_text
                };

		    console.log("content before..", template.body);
                var content = replaceTemplatePlaceholders(template.body, replacements); 
                var subject = template.subject;

		    console.log("content after..", content);
		    console.log(subject);

		    console.log("sending..");
                await sendEmail(user.email, subject, content);
		    console.log("sent the email!");
                await updateBook( book.book_id, {
                    "welcome_sent": "1"
                });
            }
		} catch ( err ) {
			console.log("err", err);
		}
        }
        resolve();
    });
}
async function processPrompts() {

    var now = moment();
    return new Promise(async (resolve, reject) => {
        var books = await fetchAllBooks()

        for ( var index in books ) {
            var book = books[index];
	    try {
                    var user = await fetchUser( book.purchaser_user_id );
		    const questions = await fetchBookQuestions(user.user_id, book.book_id);
		    for ( var index1 in questions ) {
			try {
				var question = questions[index1];
				if ( question.is_sent === 0) {
				    //check timing
				    var send_on = calculateSendDate(
					questions, 
					book.creation_datetime,
					book.prompt_frequency
				   );
				   if ( send_on.time() > now.time() ) {
					var replacements = {
					    "prompt": question.dsply_txt
					};
					var template =await fetchEmail("prompt", book.locale_id);
					var subject =template.subject;
					var content = replaceTemplatePlaceholders(template.body, replacements); 
					await sendEmail(user.email, subject, content);
					await updateBookQuestion( question.join_id, "is_sent", 1);
				   }
				}
			} catch (err1) {
				console.log("err", err);
			}
		    }
	    } catch (err) {
			console.log("err", err);
	    }
        }

        resolve();
    });
}

async function processPublishReminders() {
    return new Promise(async (resolve, reject) => {
        var books = await fetchBooksThatRequirePublish();
        for (var index in books) {
	    try {  
		    var book = books[ index ]
		    console.log("book is ", book);
		    var template =await fetchEmail("publish reminder", book.locale_id);
		    var user = fetchUser( book.purchaser_user_id );
		    var replacements = {
			"bookName": book.title,
			"startDate": book.creation_datetime
		    };

		    var content = replaceTemplatePlaceholders(template.body, replacements); 
		    await sendEmail(user.email, template.subject, content);
		    await updateBook( book.book_id, {
			"publish_reminder_sent": "1"
		    });
	    } catch (err) {
				console.log("err", err);
	    }
        }
        resolve();
    });
}

async function processPublished() {
    return new Promise(async (resolve, reject) => {
        var books = await fetchAllBooks();
        for (var index in books) {
	    try {  
		    var book = books[ index ]
		    if ( book.is_published === 1 && book.publish_reminder_sent === 1 ) {
			var template =await fetchEmail("published", book.locale_id);
			var user = fetchUser( book.purchaser_user_id );
			var replacements = {
			};

			var content = replaceTemplatePlaceholders(template.body, replacements); 
		       await sendEmail(user.email, template.subject, content);
		       await updateBook( book.book_id, {
			    "publisher_notified": "1"
			});
		    }
	    } catch (err) {
				console.log("err", err);
	    }
        }
        resolve();
    });
}

async function startProcessingEmails() {
	return new Promise(async (resolve, reject) =>  {
    // What emails do we need to send ? Check the time and compare it agaisnt our last run

    var now = new Date();

    var schedule_type = process.env['SCHEDULE_TYPE'];
    setImmediate(async () => {
        if ( schedule_type === 'WELCOME' ) {
            await processWelcome();
        } else if ( schedule_type === 'PROMPTS' ) {
            await processPrompts();
        } else if ( schedule_type === 'PUBLISH_REMINDERS' ) {
            await processPublishReminders();
        } else if ( schedule_type === 'PUBLISHed' ) {
            await processPublished();
        }
	    resolve();
    });
	});

}

module.exports = {
	processWelcome,
	processPrompts,
	processPublishReminders,
	processPublished,
	startProcessingEmails
};

