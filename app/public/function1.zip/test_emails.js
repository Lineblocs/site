process.env["SCHEDULE_TYPE"] =  "PROMPTS";

var emailFns = require("./email_fns.js");

setImmediate(async () => {
	await emailFns.processPublished();
});
