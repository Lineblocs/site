// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const express = require('express')
const bodyParser = require('body-parser')
const { fetchUserAnswer, addUserAnswer, fetchUser } = require('./data')
const { fetchQuestion, fetchQuestions, createQuestion, updateQuestion } = require('./data/questions')
const { fetchBook, fetchBookStats, fetchBooks, fetchUserBooks, fetchBookUsers, fetchBookQuestions, createBook, updateBook, createBookQuestion, addQuestions, removeBookUser, updateBookUser, answerPrompt, editAnswerPrompt, saveAnswerDraft, addBookRole, deleteBookUser, roleByBook, updateAnswerAttachments, addAttachment, delAttachment, reorderQuestions, removeAnswers, updateAttachment, fetchAnswerByQuestion } = require('./data/books')

const { fetchRoles, createRole, updateRole, deleteRole } = require('./data/roles')
const { fetchTags, fetchTagQuestions } = require('./data/tags')
const { fetchImages, createImage, updateImage, deleteImage } = require('./data/images')
const { decodeJWT, estimatePages, createS3Client, createSESClient, createEmailTemplate, replaceTemplatePlaceholders } = require('./data/utils')
const { fetchLocales } = require('./data/locales')
const { fetchAnswer, fetchBookAnswers, fetchAnswerImages, fetchUserAnswers, fetchQuestionAnswers, createAnswer, updateAnswer } = require('./data/answers')
const { addUser, addInvite, fetchUserByCognitoID,  fetchUserByEmail, fetchUserByInviteHash, updateUser, checkAndCreate } = require('./data/users')
const { buyBook } = require('./data/purchase')
const { createCognitoUser, addUserToDB, login, verifyToken } = require('./auth')
const { validateCreate } = require('./validate')
const { TEMPLATES } = require('./emails')
const {  QUESTION_TYPES, ROLE_TYPES, ROLE_LINK_TYPES } = require('./defines');
const { v4: uuidv4 } = require('uuid');
const util = require('util');
const AWS = require('aws-sdk');
const  AmazonCognitoIdentity = require( 'amazon-cognito-identity-js' );
		const { CognitoUserPool, CognitoUserAttribute, CognitoUser } = AmazonCognitoIdentity;

require('dotenv').config()

const app = express()

var cors = require('cors')
app.use(cors())



AWS.config.update({region:'eu-central-1'});
app.use(bodyParser.json())
s3 = createS3Client();
const ses = createSESClient();
function createInviteHash(length) {
	    var result           = [];
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
      result.push(characters.charAt(Math.floor(Math.random() *
 charactersLength)));
   }
   return result.join('');
}
function createTempPassword() {
      var pwdChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
      var symChars = "!@#$%^*";
var pwdLen = 10;
var symLen = 4;
var randPassword = Array(pwdLen).fill(pwdChars).map(function(x) { return x[Math.floor(Math.random() * x.length)] }).join('');
randPassword += Array(symLen).fill(symChars).map(function(x) { return x[Math.floor(Math.random() * x.length)] }).join('');
return randPassword;
  }
async function createUser( email, given_name, family_name, locale ) {
	console.log( arguments );
	locale= locale||'en-US';
	var params = {
		given_name,
		family_name,
		email,
		locale: locale
	};
	return new Promise(async (resolve, reject) => {
		// ES Modules, e.g. transpiling with Babel
		var password = createTempPassword();



		var poolData = {
			UserPoolId: 'eu-central-1_NNENTtHJf', // Your user pool id here
			ClientId: '4dofrnhk5fvl6et3nm9lobklj6', // Your client id here
		};
		var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);

		var attributeList = [];

		var dataEmail = {
			Name: 'email',
			Value: params.email,
		};

		var given_name = {
			Name: 'given_name',
			Value: params.given_name
		};
		var family_name = {
			Name: 'family_name',
			Value: params.family_name
		};
		var locale = {
			Name: 'locale',
			Value: params.locale
		};


console.log(given_name);
		var attributeEmail = new AmazonCognitoIdentity.CognitoUserAttribute(dataEmail);
		attributeList.push(attributeEmail);
		attributeList.push(given_name);
		attributeList.push(family_name);
		attributeList.push(locale);

		userPool.signUp(email, password, attributeList, null, function(
			err,
			result
		) {
			if (err) {
				reject(err);
				return;
			}
			console.log( result );
			var cognitoUser = result.user;
			console.log('user name is ' + cognitoUser.getUsername());
			console.log(cognitoUser);
			resolve( {
				"result": result,
				"password": password
			});
		});
	});

}

async function sendEmail(type, email, replacements)
{
  var from = "bounce@bounce.anecdobio.com";
  var {body,subject} = createEmailTemplate( type, replacements );

  var params = {
    Destination: {
      ToAddresses: [email],
    },
    Message: {
      Body: {
        Text: {
          Charset: "UTF-8",
          Data: body
        },
        Html: {
          Charset: "UTF-8",
          Data: body
        },
      },

      Subject: {
        Charset: "UTF-8",
        Data: subject
      },
    },
    Source: from
  };

  return ses.sendEmail(params).promise()
}
function createPaginationArgs(req) {
  var params = {
    offset: 0,
    limit: 10
  };
  if ( req.query.offset ) {
    params.offset =  req.query.offset;
  }
  if ( req.query.limit ) {
    params.limit =  req.query.limit;
  }
  return params;
}

function wrapAsync(fn) {
  return function(req, res, next) {
    fn(req, res, next).catch(next);
  };
}

async function roleInBook( user, book ) {
  var result = await roleByBook( book.book_id, user.user_id );
  return result;
}



async function storeFile(bookId, questionId, name, buff)
{
  return new Promise(async function(resolve, reject) {
    // Read options from the event parameter.
    var origimage = buff;
    var id = uuidv4();
    const dstBucket = "anecdobio";
	  var re = /(?:\.([^.]+))?$/;
	var exts = re.exec(name);
	  var ext;

	 if ( exts[1] ) {
		 ext = '.'+exts[1];
	 } else {
		 ext = '';
	 }

    const dstKey    = `${bookId}/${questionId}/${id}${ext}`;
    try {
        const destparams = {
            Bucket: dstBucket,
            Key: dstKey,
            Body: buff,
            ContentType: "image"
        };

        const putResult = await s3.putObject(destparams).promise();

    } catch (error) {
        console.log(error);
        reject( error );
        return;
    }

    console.log('Successfully uploaded to ' + dstBucket + '/' + dstKey);
      resolve( {
        dstKey,
        dstBucket,
        id,
        name
      });

  });


}
// Fetch Book
app.get('/books', wrapAsync(async (req, res) => {
  var params = createPaginationArgs( req );
  const book = await fetchBooks(params);
  res.json(book)
}))


// Fetch Book
app.get('/book/:book_id', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
	console.log("book id is ", req.params.book_id);
  const user = await fetchUserByCognitoID(id);
	console.log("user is ", user);
  const book = await fetchBook(req.params.book_id, user.user_id);
  const stats = await fetchBookStats(req.params.book_id);
  book['stats'] = stats;
  const users = await fetchBookUsers(req.params.book_id);
  book['users'] = users;
  const questions = await fetchBookQuestions(user.user_id, req.params.book_id);
  book['questions'] = questions;
  book['roleInBook'] = await roleInBook( user, book );

  res.json(book)
}))

// Delete user from book
app.delete('/book/:book_id/user/:user_id', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  var userId = req.params.user_id;
  var bookId = req.params.book_id;
  await removeBookUser( bookId, userId );
  res.status(200).json({});
}))
// Get self
app.get('/self', wrapAsync(async (req, res) => {
var userId = req.query.cognito_id;
  const user = await fetchUserByCognitoID(userId);

  res.status(200).json(user);
}))


// Get invite by hash
app.get('/inviteByHash', wrapAsync(async (req, res) => {
var userId = req.query.cognito_id;
var hash = req.query.hash;
  const user = await fetchUserByInviteHash(hash);

  res.status(200).json(user);
}))






// Update user from book
app.put('/book/:book_id/user/:user_id', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  var userId = req.params.user_id;
  var bookId = req.params.book_id;
  var access_type = req.body.access_type;
  var user_role = req.body.user_role;
  var access_list = req.body.access_list;
  await updateBookUser( bookId, userId, user_role, access_type, access_list );
  res.status(200).json({});
}))

// Create question
app.post('/book/:book_id/question', wrapAsync(async (req, res) => {
  var userId = req.query.cognito_id;
  var bookId = req.params.book_id;
  const user = await fetchUserByCognitoID(userId);
  const book = await fetchBook(bookId, user.user_id);
  var text = req.body.text;
  var result = await createBookQuestion( bookId, text, book['locale_id']);
  var question_id = result.question_id;
  res.status(200).json({
    'question_id': question_id
  });
}))

// Create question
app.post('/book/:book_id/addQuestions', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  var bookId = req.params.book_id;
  var ids = req.body.question_ids;
  var text = req.body.text;
  await addQuestions( bookId, ids );
  res.status(200).json({});
}))

// Reorder
app.post('/book/:book_id/reorderQuestions', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  var bookId = req.params.book_id;
  var sort_data= req.body.sort_data;
  var text = req.body.text;
  await reorderQuestions( bookId, sort_data );
  res.status(200).json({});
}))



// Create question
app.post('/book/:book_id/question/:question_id', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  const user = await fetchUserByCognitoID(id);
  var bookId = req.params.book_id;
  var txt= req.body.text;
  var book = await fetchBook(bookId);
  await createBookQuestion( bookId, txt, book.locale_id );
  res.status(201).json({});
}))


// Create answer
app.post('/book/:book_id/question/:question_id/saveAnswerDraft', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  const user = await fetchUserByCognitoID(id);
  var bookId = req.params.book_id;
  var questionId = req.params.question_id;
  var txt= req.body.txt;
  var join_id= req.body.join_id;
  var attachments= [];

  var result = await saveAnswerDraft( bookId, questionId,join_id, user.user_id, txt, attachments );
	console.log("result", result);
  var answer_id;
  if  ( result.generatedFields.length > 0 ) {
	answer_id = result.generatedFields[0].longValue;
  } else {
	 var answer = await fetchAnswerByQuestion( bookId, user.user_id, questionId );
	answer_id = answer.answer_id;
  }


  res.status(201).json({
	  answer_id: answer_id
  });
}))


// Create answer
app.post('/book/:book_id/question/:question_id/answer', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  const user = await fetchUserByCognitoID(id);
  var bookId = req.params.book_id;
  var questionId = req.params.question_id;
  var txt= req.body.txt;
  var join_id= req.body.join_id;
  var attachments= [];

  var result = await answerPrompt( bookId, questionId, join_id,user.user_id, txt, attachments );
var answer_id;
  if  ( result.generatedFields.length > 0 ) {
	answer_id = result.generatedFields[0].longValue;
  } else {
	 var answer = await fetchAnswerByQuestion( bookId, user.user_id, questionId );
	answer_id = answer.answer_id;
  }


  res.status(201).json({
	  answer_id: answer_id
  });
}))

// Edit answer
app.put('/book/:book_id/question/:question_id/answer/:answer_id', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  const user = await fetchUserByCognitoID(id);
  var bookId = req.params.book_id;
  var questionId = req.params.question_id;
  var answerId = req.params.answer_id;
  var txt= req.body.txt;
  var attachments= [];
  await editAnswerPrompt( bookId, questionId, answerId, user.user_id, txt, 1 );
  res.status(201).json({});
}))

// Delete answers
app.delete('/book/:book_id/question/:question_id/answer', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  const user = await fetchUserByCognitoID(id);
  var bookId = req.params.book_id;
  var questionId = req.params.question_id;
  await removeAnswers( bookId, questionId );
  res.status(201).json({
  });
}))


// Create image
app.post('/book/:book_id/question/:question_id/answer/:answer_id/image', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  const user = await fetchUserByCognitoID(id);
  var bookId = req.params.book_id;
  var questionId = req.params.question_id;
  var name = req.body.name;
  var caption = req.body.caption;
  var sort = req.body.sort;
  var key = req.body.key;
  var bucket = "aws-s3-cors-s3uploadbucket-eacw8g4n2pp3";
  var txt= req.body.txt;
  var orientation= req.body.orientation;
  var attachments= [];

  var answer_id = req.params.answer_id;
  //var fileObj =  await storeFile(bookId, questionId, name, buff);
  await addAttachment(answer_id, name, caption, key, bucket, sort, orientation);
  res.status(201).json({});
}))

// Delete image
app.delete('/book/:book_id/question/:question_id/answer/:answer_id/image/:image_id', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  const user = await fetchUserByCognitoID(id);
  var bookId = req.params.book_id;
  var questionId = req.params.question_id;
  var imageId = req.params.image_id;
  var answer_id = req.params.answer_id;
  await delAttachment(imageId);
  res.status(200).json({});
}))

// Update image
app.put('/book/:book_id/question/:question_id/answer/:answer_id/image/:image_id', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  const user = await fetchUserByCognitoID(id);
  var bookId = req.params.book_id;
  var questionId = req.params.question_id;
  var imageId = req.params.image_id;
  var answer_id = req.params.answer_id;
  var params = req.body;
  await updateAttachment(imageId, params);
  res.status(200).json({});
}))


// Get all images by answer
app.get('/book/:book_id/question/:question_id/answer/:answer_id/images', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  const user = await fetchUserByCognitoID(id);
  var bookId = req.params.book_id;
  var questionId = req.params.question_id;
  var answerId = req.params.answer_id;
  var images = await fetchAnswerImages( bookId, questionId, answerId );
  res.status(201).json(images);
}))















// Create Book
app.post('/book', wrapAsync(async (req, res) => {
  var { title, purchaser_user_id,author_user_id, json_data, is_published, is_retired } = req.body;
  const book = await createBook(title, purchaser_user_id, author_user_id, json_data, is_published, is_retired);
  res.send(null);

}))

// Update Book
app.put('/book/:book_id', wrapAsync(async (req, res) => {
  const book = await updateBook(req.params.book_id, req.body);
  res.send(null);

}))

// Delete user from book
app.delete('/book/:book_id/user/:user_id', wrapAsync(async (req, res) => {
  var role_id = req.body.role_id;
  const book = await deleteBookUser(req.params.book_id, req.params.user_id, role_id);
  res.send(null);

}))

// Invite user to Book
app.post('/book/:book_id/sendInvite', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  const user = await fetchUserByCognitoID(id);
  var book_id = req.params.book_id;
  var book = await fetchBook( book_id, user.user_id );
  var body = req.body;
  var username = body.username;
  var email = body.email;
  var first = body.first;
  var last = body.last;
  var locale = book.locale_id;
  var cognito_id = body.cognito_id;
  var temp_password = body.temp_password;
  var role = body.role;
  var role_question_id = body.role_question_id;
  var link = body.link; // the entire book or selected prompts
  var link_val = link;
  var link_to= book.book_id;

  if ( link_val === 'BOOK' ) {
    link_to= book.book_id;
  } else if ( link_val === 'BOOK_JOIN' ) {
    link_to= role_question_id;
  }

  var receiver;
	console.log('fetching by email ', email);
	var exists = false;
	var cog_resp;
  var receiver = await fetchUserByEmail( email );

  if ( !receiver ) {
	var cognito_id = "";
	var params = [cognito_id, email, first, last, locale];
	console.log('add params ', params);
  	await addUser(cognito_id, email, first, last, locale);
  	receiver= await fetchUserByEmail(email);
	console.log('receiver is ', receiver);
  	var role = await addBookRole(book.book_id, receiver.user_id, role, link, link_to);
    var role_id = role.generatedFields[0].longValue;
    var hash = createInviteHash(12);
  	await addInvite(user.user_id, receiver.user_id, role_id, hash);

    var link_url = `https://anecdobio.com/register-invite?token=${hash}`;
  	await sendEmail('new-invited', receiver.email, {

	  "bookTitle": book.title,
      	   "email": receiver.email,
           "inviteByFirstName": user.first_name,
           "inviteByLastName": user.last_name,
           "roleAction": 
        "hash": hash,
        'link_url': link_url
    });

  res.json({});
	  return;

  }
    receiver= await fetchUserByEmail(email);
	  console.log("current user ", receiver);
	  console.log('receiver is ', receiver);
    await addBookRole(book.book_id, receiver.user_id, role, link_val, link_to);
    await sendEmail('exist-invited', receiver.email, {
	  "book_name": book.title,
      "email": receiver.email
    });
    res.json({});
}))

// Fetch Question
app.get('/questions', wrapAsync(async (req, res) => {
  var params = createPaginationArgs( req );
  const question = await fetchQuestions(params);
  res.json(question)
}))


// Fetch Question
app.get('/question/:question_id', wrapAsync(async (req, res) => {
  const question = await fetchQuestion(req.params.question_id)
  res.json(question)

}))

// Create Question
app.post('/question', wrapAsync(async (req, res) => {
  var { title, dsply_text, json_data, is_retired } = req.body;
  const question = await createQuestion(title, dsply_text, json_data, is_retired);
  res.send(null);

}))

// Update Question
app.put('/question/:question_id', wrapAsync(async (req, res) => {
  const question = await updateQuestion(req.params.question_id, req.body);
  res.send(null);

}))


// Fetch Role
app.get('/roles', wrapAsync(async (req, res) => {
  var params = createPaginationArgs( req );
  const role = await fetchRoles(params);
  res.json(role)
}))


// Create Role
app.post('/role', wrapAsync(async (req, res) => {
  var body = req.body;
  var role_type = body.role_type_id;
  var role_type_link = body.role_type_link-id;
  var role_type_link_to = body.role_type_link_to_id;
  var user_id = body.user_id;
  const role = await createRole(role_type, role_type_link, role_type_link_to, user_id);
  res.send(null);

}))

// Update Role
app.put('/role/:role_id', wrapAsync(async (req, res) => {
  const role = await updateRole(req.params.role_id, req.body);
  res.send(null);

}))

// Delete Role
app.delete('/role/:role_id', wrapAsync(async (req, res) => {
  await deleteRole(req.params.role_id);
  res.send(null);

}))

// Fetch Image
app.get('/images', wrapAsync(async (req, res) => {
  var params = createPaginationArgs( req );
  const image = await fetchImages(params);
  res.json(image)
}))


// Create Image
app.post('/image', wrapAsync(async (req, res) => {
  const image = await createImage(req.body);
  res.send(null);

}))

// Update Image
app.put('/image/:image_id', wrapAsync(async (req, res) => {
  const image = await updateImage(req.params.image_id, req.body);
  res.send(null);

}))

// Delete Image
app.delete('/image/:image_id', wrapAsync(async (req, res) => {
  await deleteImage(req.params.image_id);
  res.send(null);

}))
// Login
app.post('/login', wrapAsync(async (req, res) => {
  const idToken = await login(req.body.username, req.body.password)
  res.json({ idToken })
}))

// Login
app.get('/userByCognitoId', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  const user = await fetchUserByCognitoID(id);
  res.json({ idToken })
}))


// Create user
app.post('/user', wrapAsync(async (req, res) => {
  var body = req.body;
  var username = body.username;
  var email = body.email;
  var first = body.first;
  var last = body.last;
  var locale = body.locale;
  var cognito_id = body.cognito_id;

  await addUser(cognito_id, email, first, last, locale);
  res.json({});
}))

// Create user
app.put('/user/:user_id', wrapAsync(async (req, res) => {
  var body = req.body;
  var username = body.username;
  var email = body.email;
  var first = body.first;
  var last = body.last;
  var locale = body.locale;
  var cognito_id = body.cognito_id;
  var user_id = req.params.user_id;
  await updateUser(cognito_id, user_id, email, first, last, locale);
  res.json({});
}))



// Create user
app.post('/users', wrapAsync(async (req, res) => {
  await createCognitoUser(req.body.username, req.body.password, req.body.email)
  res.json({ username: req.body.username, email:req.body.email })
}))

// Fetch a user answer
app.get('/answer/:answer_id', wrapAsync(async (req, res) => {
  var user = decodeJWT( req );
  const answer_id = req.params.answer_id;
  const answer = await fetchAnswer(user_id, req.params.question_id)
  res.json(answer)
}))

// Fetch a user answer
app.post('/answer', wrapAsync(async (req, res) => {
  var {book_question_join_id, user_id, answer_text} = req.body;
  const answer = await createAnswer( book_question_join_id, user_id, answer_text);

  res.json(answer)
}))

// Fetch a user answer
app.put('/answer/:answer_id', wrapAsync(async (req, res) => {
  const answer_id = req.params.answer_id;
  const body= req.body;
  const answer = await updateAnswer(answer_id, body.answer_text);
  res.json(answer)
}))


// Fetch a user answer
app.get('/booksByUser', wrapAsync(async (req, res) => {
  var id = req.query.cognito_id;
  const user = await fetchUserByCognitoID(id);

  const books = await fetchUserBooks(user.user_id);
  res.json(books)
}))



// Fetch a user answer
app.get('/answersByUser', wrapAsync(async (req, res) => {
  const limit = req.query.limit || 10;
  const user_id = req.query.user_id;
  const answer = await fetchUserAnswers(user_id);
  res.json(answer)
}))

// Fetch a user answer
app.get('/answersByQuestion', wrapAsync(async (req, res) => {
  const limit = req.query.limit || 10;
  const question_id = req.query.question_id;
  const user_id = "";
  const answer = await fetchQuestionAnswers(user_id, question_id)
  res.json(answer)
}))

// Fetch a user answer
app.get('/answersByBook', wrapAsync(async (req, res) => {
  const limit = req.query.limit || 10;
  const book_id = req.query.book_id;
  const user_id = "";
  const answer = await fetchBookAnswers(user_id, book_id);
  res.json(answer)
}))

// Fetch a user answer
app.get('/questionsByBook', wrapAsync(async (req, res) => {
  const limit = req.query.limit || 10;
  const book_id = req.query.book_id;
  const user = await fetchUserByCognitoID( req.query.cognito_id );
  const user_id = user.user_id;
  const answer = await fetchBookQuestions(user_id, book_id);
  res.json(answer)
}))

// Fetch a user answer
app.get('/tags', wrapAsync(async (req, res) => {
  const user_id = "";
  const book_id = req.query.book_id;
  const tags = await fetchTags(book_id);
  res.json(tags)
}))




// Fetch a user answer
app.get('/locales', wrapAsync(async (req, res) => {
  const locales = await fetchLocales();
  res.json(locales)
}))

// Purchase
app.post('/purchase/buyBook', wrapAsync(async (req, res) => {
	const info = req.body;

  const result = await buyBook(info);
  res.json(result);
}))

app.use(function(error, req, res, next) {
  res.status(400).json({ message: error.message });
});

module.exports = app
