var QUESTION_TYPES = {
  "SYSTEM": "1",
  "CUSTOM": "2"
};
var ROLE_TYPES = {
  "author": "4",
  "reader": "5"
};
var ROLE_LINK_TYPES = {
  "BOOK": "6",
  "ANSWER": "7",
  "BOOK_JOIN": "8"
};

module.exports = {
  QUESTION_TYPES,
  ROLE_LINK_TYPES,
  ROLE_TYPES
};
