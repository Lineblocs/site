
const { fetchEmail  } = require('./data/emails')
const { fetchUserByEmail, fetchUserByCognitoID  } = require('./data/')
const {createEmailTemplate, replaceTemplatePlaceholders } = require('./data/utils')
var TARGET_USER_POOL = 'eu-central-1_NNENTtHJf';
exports.handler = (event, context, callback) => {
    //
    if(event.userPoolId === TARGET_USER_POOL) {
        // Identify why was this function invoked
        var username = event.userName;
        if(event.triggerSource === "CustomMessage_SignUp") {
            var verify_code = event.request.codeParameter;
            var attrs = event.request.userAttributes;
            console.log("attrs are ", attrs);
            fetchUserByCognitoID( username ).then(function( user ) {

                fetchEmail("welcome", user.locale_id).then((template) => {
                    console.log( template );
                    var body = replaceTemplatePlaceholders( template.body, {} );
                    // Ensure that your message contains event.request.codeParameter. This is the placeholder for code that will be sent
                    event.response.smsMessage = body;
                    event.response.emailSubject = template.subject;
                    event.response.emailMessage = body;
                    callback( null, event );
                }, function( err ) { 
                    callback( err, null );
                });
            });
        } else if(event.triggerSource === "CustomMessage_ForgotPassword") {
            var attrs = event.request.userAttributes;
            console.log("attrs are ", attrs);
            fetchUserByCognitoID( username ).then(function( user ) {

                fetchEmail("password reset", user.locale_id).then((template) => {
                    console.log( template );
                    var body = replaceTemplatePlaceholders( template.body, {} );
                    // Ensure that your message contains event.request.codeParameter. This is the placeholder for code that will be sent
                    event.response.smsMessage = body;
                    event.response.emailSubject = template.subject;
                    event.response.emailMessage = body;
                    callback( null, event );
                }, function( err ) { 
                    callback( err, null );
                });
            });
        }
        // Create custom message for other events
        return;
    }
    callback(null, event);
};