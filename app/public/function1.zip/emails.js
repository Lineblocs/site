var TEMPLATES = {
  'new-invited': {
      subject: 'Anecdobio - You have been invited.',
      body: `
You have been invited to book: %%%book_name%%%. To register your account please go to <a href="%%%link_url%%%">%%%link_url%%%</a>
<br/>
<br/>
Thanks,
Anecdobio team
`
  },
  'exist-invited': {
      subject: 'Anecdobio - You have been invited.',
      body: `
You have been added to book: %%%book_name%%%. This book should now appear in your dashboard.<br/><br/>

Thanks,
Anecdobio team 
`
  }
};

module.exports = {
  TEMPLATES
};
