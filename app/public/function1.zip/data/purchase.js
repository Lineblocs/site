const { executeReadSql, executeWriteSql } = require('./utils')
const { charge } = require('../stripe')
const { addUser, checkAndCreate } = require('./users')
const { createBook } = require('./books')
const { createRole } = require('./roles')
const { createAddress } = require('./address')
const { createOrder } = require('./order')
const { createOrderLine } = require('./orderLine')

const buyBook = async purchaseInfo => {
	const {
		token,
		purchaser,
		author,
		book,
		address,
		amount,
		currency,
		description,
		package,
		type
	} = purchaseInfo

	try {
		const stripeChargeResult = await charge({ token, name: purchaser.name, email: purchaser.email, amount, currency, description })

		const purchaseUser = await checkAndCreate({
			cognito_id: null,
			email: purchaser.email,
			first_name: purchaser.name.split(' ').slice(0, -1).join(' '),
			last_name: purchaser.name.split(' ').slice(-1).join(' '),
			locale: 1
		})

		const shippingAddress = await createAddress({
			...address.shipping,
			user_id: purchaseUser.user_id
		})

		const billingAddress = await createAddress({
			...address.billing,
			user_id: purchaseUser.user_id
		})

		let bookCreated = {}

		if (type === 'author') {
			bookCreated = await createBook(
				book.title,
				purchaseUser.user_id,
				purchaseUser.user_id,
				null,
				'0',
				'0',
				book.start_datetime,
				book.welcome_text)

			const roleWriter = await createRole(
				 '4',
				 '6',
				 bookCreated['generatedFields'][0]['longValue'],
				 purchaseUser.user_id,
				 bookCreated['generatedFields'][0]['longValue']
			 )
		} else {
			const authorUser = await checkAndCreate({
				cognito_id: null,
				email: author.email,
				first_name: author.firstName,
				last_name: author.lastName,
				locale: 1
			})

			bookCreated = await createBook(
				book.title,
				purchaseUser.user_id,
				authorUser.user_id,
				null,
				'0',
				'0',
				book.start_datetime,
				book.welcome_text)

			const roleWriter = await createRole(
				'4',
				'6',
				bookCreated['generatedFields'][0]['longValue'],
				authorUser.user_id,
				bookCreated['generatedFields'][0]['longValue'])

			const rolePurchaser = await createRole(
				'1',
				'6',
				bookCreated['generatedFields'][0]['longValue'],
				purchaseUser.user_id,
				bookCreated['generatedFields'][0]['longValue'])
		}

		const orderCreated = await createOrder({
			user_id: purchaseUser.user_id,
			shipping_address_id: shippingAddress['generatedFields'][0]['longValue'],
			billing_address_id: billingAddress['generatedFields'][0]['longValue'],
			book_id: bookCreated['generatedFields'][0]['longValue'],
			total: package['price'],
			tax_total: 0
		})

		const orderLineCreated = await createOrderLine({
			order_id: orderCreated['generatedFields'][0]['longValue'],
			product_id: package['product_id'],
			quantity: 1,
			unit_price: package['price'],
			unit_cost: package['cost'],
			tax_total: 0
		})


		return Promise.resolve(stripeChargeResult)
	} catch (error) {
		return Promise.reject(error)
	}
}


module.exports = {
  buyBook
};
