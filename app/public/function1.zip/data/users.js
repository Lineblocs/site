// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const { executeReadSql, executeWriteSql } = require('./utils')

const addUser = async (cognito_id, email, first_name, last_name, locale) => {
	console.log('addUser', arguments);
	console.log('LOCALE IS ', locale);
  const sql = `INSERT INTO user (cognito_id, email, first_name, last_name, locale_id, json_data) VALUES (:cognito_id, :email, :first_name, :last_name, :locale_id, '{}')`
const  parameters = [
    {
      name: 'cognito_id',
      value: { stringValue: cognito_id, isNull: true },
    },
    {
      name: 'email',
      value: { stringValue: email}
    },
    {
      name: 'first_name',
      value: { stringValue: first_name}
    },
    {
      name: 'last_name',
      value: { stringValue: last_name}
    },
    {
      name: 'locale_id',
      value: { longValue: locale}
    }
  ]
  const result = await executeWriteSql(sql, parameters)
	console.log('ADD RESULT', result);
  return result;

}
const updateUser = async (cognito_id, user_id, email, first_name, last_name, locale) => {
	console.log('addUser', arguments);
	console.log('LOCALE IS ', locale);
  const sql = `UPDATE user SET cognito_id=:cognito_id, first_name=:first_name, last_name=:last_name WHERE user_id = :user_id`;
const  parameters = [
    {
      name: 'cognito_id',
      value: { stringValue: cognito_id }
    },
    {
      name: 'user_id',
      value: { longValue: user_id }
    },
    {
      name: 'first_name',
      value: { stringValue: first_name}
    },
    {
      name: 'last_name',
      value: { stringValue: last_name}
    }
  ]
  const result = await executeWriteSql(sql, parameters)
  return result;

}

function createInviteHash() {
  return '';
}
const addInvite = async (user_id,target_user_id,role_id,hash) => {
	console.log('addInvite', arguments);

  const sql = `INSERT INTO invite (user_id, target_user_id, role_id, invite_hash)
  VALUES (:user_id, :target_user_id, :role_id, :invite_hash);`;
const  parameters = [
    {
      name: 'user_id',
      value: { longValue: user_id }
    },
{
      name: 'target_user_id',
      value: { longValue: target_user_id }
    },
{
      name: 'role_id',
      value: { longValue: role_id }
    },
{
      name: 'invite_hash',
      value: { stringValue: hash }
    },

  ]
  const result = await executeWriteSql(sql, parameters)
  return result;

}


const fetchUser= async (id) => {
  let sql = 'SELECT * FROM user WHERE user_id = :id';
  const parameters = [
    {
      name: 'id',
      value: { longValue: id}
    }
  ];

	try {
		const result = await executeReadSql(sql, parameters)
		if (result.length > 0) {
			return Promise.resolve(result[0])
		} else {
			return Promise.resolve(null)
		}
	} catch (error) {
		return Promise.reject(error)
	}
}
<<<<<<< HEAD
=======
const fetchUsers = async () => {
  const parameters = [
  ];
  const sql = 'SELECT * FROM USER';
  const result = await executeReadSql(sql, parameters)
  return result
}
>>>>>>> 2cc4677d7da46a610fbb38a188f61f38727c13c6

const fetchUserByEmail= async (email) => {
  let sql = 'SELECT * FROM user WHERE email = :email';
  const parameters = [
    {
      name: 'email',
      value: { stringValue: email}
    }
  ];

	try {
		const result = await executeReadSql(sql, parameters)
		if (result.length > 0) {
			return Promise.resolve(result[0])
		} else {
			return Promise.resolve(null)
		}
	} catch (error) {
		return Promise.reject(error)
	}
}

const fetchUserByCognitoID= async (id) => {
  let sql = 'SELECT * FROM user WHERE cognito_id = :id';
  const parameters = [
    {
      name: 'id',
      value: { stringValue: id}
    }
  ];

	console.log("query params ", parameters);
  const result = await executeReadSql(sql, parameters)
	console.log("user result is ", result);
  return result[0];
}

const fetchUserByInviteHash= async (hash) => {
  let sql = `SELECT user.*, invite.invite_hash FROM invite
INNER JOIN user ON user.user_id = invite.target_user_id
WHERE invite.invite_hash = :hash`;
  const parameters = [
    {
      name: 'hash',
      value: { stringValue: hash}
    }
  ];

	console.log("query params ", parameters);
  const result = await executeReadSql(sql, parameters)
	console.log("user result is ", result);
  return result[0];
}

const checkAndCreate = async data => {
	const { cognito_id, email, first_name, last_name, locale } = data
	try {
		let user = await fetchUserByEmail(email)
		if (!user) {
			await addUser(cognito_id, email, first_name, last_name, locale)
			user = await fetchUserByEmail(email)
		}

		return Promise.resolve(user)
	} catch (error) {
		return Promise.reject(error)
	}
}

module.exports = {
  addUser,
  updateUser,
  fetchUserByEmail,
  fetchUserByCognitoID,
	fetchUserByInviteHash,
  fetchUser,
<<<<<<< HEAD
=======
  fetchUsers,
>>>>>>> 2cc4677d7da46a610fbb38a188f61f38727c13c6
	addInvite,
	checkAndCreate
};
