
const { fetchEmail  } = require('./data/emails')

const { fetchUsers, fetchUser } = require('./data')

const { fetchAllBooks, fetchAllBookQuestions, updateBookQuestion, updateBook, fetchAllBooksThatRequirePublish } = require('./data/books.js')
const {createEmailTemplate, replaceTemplatePlaceholders, sendEmail, calculateSendDate } = require('./data/utils')
const moment = require('moment');
const { fetchUserByCognitoID } = require('./data/users');

var EMAILS = {

}
function sent_welcome_email( book ) {
    if ( book.welcome_sent === 1 ) {
        return true;
    }
    return false;
}

async function processWelcome() {
    return new Promise(async (resolve, reject) => {
        var books = await fetchAllBooks();
        for (var index in books) {
            var book = books[ index ];
            if ( !send_welcome_email( book ) ) {
                var template =await fetchEmail("welcome", book.locale_id);

                var user = fetchUser( book.purchaser_user_id );
                var replacements = {
                    "purchaserFirstName": user.first_name,
                    "welcomeMessage": book.welcome_text
                };

                var content = replaceTemplatePlaceholders(template.body, replacements); 
                var subject = template.subject;
                await sendEmail(user.email, subject, content);
                await updateBook( book.book_id, {
                    "welcome_sent": 1
                });
            }
        }
        resolve();
    });
}
async function processPrompts() {
    var now = moment();
    return new Promise(async (resolve, reject) => {
        var books = await fetchAllBooks()

        for ( var index in books ) {
            var book = books[index];
            const questions = await fetchAllBookQuestions(user.user_id, req.params.book_id);
            for ( var index1 in questions ) {
                var question = questions[index1];
                if ( !question.is_sent ) {
                    //check timing
                    var send_on = calculateSendDate(
                        questions, 
                        book.creation_datetime,
                        book.prompt_frequency
                   );
                   if ( send_on.time() > now.time() ) {
                        var replacements = {
                            "prompt": question.dsply_txt
                        };
                        var template =await fetchEmail("prompt", book.locale_id);
                        var subject =template.subject;
                        var content = replaceTemplatePlaceholders(template.body, replacements); 
                        await sendEmail(user.email, subject, content);
                        await updateBookQuestion( question.join_id, "is_sent", 1);
                   }
                }
            }
        }
        resolve();
    });
}

async function processPublishReminders() {
    return new Promise(async (resolve, reject) => {
        var books = await fetchAllBooksThatRequirePublish();
        for (var index in books) {
            var book = books[ index ]
            var template =await fetchEmail("publish reminder", book.locale_id);
            var user = fetchUser( book.purchaser_user_id );
            var replacements = {

            };

            var content = replaceTemplatePlaceholders(template.body, replacements); 
            await sendEmail(user.email, template.subject, content);
            await updateBook( book.book_id, {
                "publish_reminder_sent": 1
            });
        }
        resolve();
    });
}

async function processPublished() {
    return new Promise(async (resolve, reject) => {
        var books = await fetchAllBooks();
        for (var index in books) {
            var book = books[ index ]
            if ( book.is_published === 1 && book.publish_reminder_sent === 1 ) {
                var template =await fetchEmail("published", book.locale_id);
                var user = fetchUser( book.purchaser_user_id );

                var user = fetchUser( book.purchaser_user_id );
                var replacements = {
                };

                var content = replaceTemplatePlaceholders(template.body, replacements); 
               await sendEmail(user.email, template.subject, content);
               await updateBook( book.book_id, {
                    "publisher_notified": 1
                });
            }
        }
        resolve();
    });
}

exports.handler = (event, context, callback) => {
    // What emails do we need to send ? Check the time and compare it agaisnt our last run

    var now = new Date();
    var schedule_type = process.env['SCHEDULE_TYPE'];
    setImmediate(async () => {
        if ( schedule_type === 'WELCOME' ) {
            await processWelcome();
        } else if ( schedule_type === 'PROMPTS' ) {
            await processPrompts();
        } else if ( schedule_type === 'PUBLISH_REMINDERS' ) {
            await processPublishReminders();
        } else if ( schedule_type === 'PUBLISHed' ) {
            await processPublished();
        }
        callback(null, event)
    });
};
