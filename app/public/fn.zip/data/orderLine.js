const { executeReadSql, executeWriteSql } = require('./utils')

const createOrderLine = async data => {
	const { order_id, product_id, quantity, unit_price, unit_cost, tax_total } = data

	const sql = `INSERT INTO order_line (order_id, product_id, quantity, unit_price, unit_cost, tax_total) VALUES (:order_id, :product_id, :quantity, :unit_price, :unit_cost, :tax_total)`
	const  parameters = [
    {
      name: 'order_id',
      value: { longValue: order_id },
    },
    {
      name: 'product_id',
      value: { longValue: product_id}
    },
    {
      name: 'quantity',
      value: { longValue: quantity}
    },
    {
      name: 'unit_price',
      value: { longValue: unit_price}
    },
		{
      name: 'unit_cost',
      value: { longValue: unit_cost}
    },
		{
      name: 'tax_total',
      value: { longValue: tax_total}
    }
  ]

	try {
		const result = await executeWriteSql(sql, parameters)
		console.log('ADD RESULT', result)

		return Promise.resolve(result)
	} catch (error) {
		return Promise.reject(error)
	}
}

module.exports = {
  createOrderLine
};
