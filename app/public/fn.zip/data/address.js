const { executeReadSql, executeWriteSql } = require('./utils')

const createAddress = async data => {
	const { user_id, address1, address2, city, zip, state, country } = data

	const sql = `INSERT INTO address (user_id, address1, address2, city, zip, state, country, last_modified_user_id) VALUES (:user_id, :address1, :address2, :city, :zip, :state, :country, :last_modified_user_id)`
	const  parameters = [
    {
      name: 'user_id',
      value: { longValue: user_id },
    },
    {
      name: 'address1',
      value: { stringValue: address1}
    },
    {
      name: 'address2',
      value: { stringValue: address2, isNull: true }
    },
    {
      name: 'city',
      value: { stringValue: city}
    },
    {
      name: 'zip',
      value: { stringValue: zip}
    },
		{
      name: 'state',
      value: { stringValue: state}
    },
		{
      name: 'country',
      value: { stringValue: country}
    },
		{
      name: 'last_modified_user_id',
      value: { longValue: user_id}
    }
  ]

	try {
		const result = await executeWriteSql(sql, parameters)
		console.log('ADD RESULT', result)

		return Promise.resolve(result)
	} catch (error) {
		return Promise.reject(error)
	}
}

module.exports = {
  createAddress
};
