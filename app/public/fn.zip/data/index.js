// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const fetchUserAnswer = require('./answers')
const addUserAnswer= require('./addUserAnswer')
const addUser= require('./users')
const fetchUser= require('./fetchUser')
const fetchUsers= require('./fetchUsers')
const fetchQuestion= require('./questions')



module.exports = {
  fetchUserAnswer,
  addUserAnswer,
  addUser,
  fetchUser,
  fetchQuestion
 
}
