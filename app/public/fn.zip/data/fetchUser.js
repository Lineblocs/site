// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const { executeReadSql } = require('./utils')

const fetchUser = async (username, question_id) => {
  const parameters = [
    {
      name: 'user_id',
      value: { stringValue: username }
    },
    {
      name: 'cognito_id',
      value: { longValue: question_id}
    }
  ]
  const sql = 'SELECT * FROM USER \
  WHERE cognito_id = :cognito_id OR user_id = :user_id'
  const result = await executeReadSql(sql, parameters)
  return result
}

module.exports = fetchUser