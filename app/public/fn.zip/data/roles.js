// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const { executeReadSql, executeWriteSql } = require('./utils')
function addParam( sql, data, key, last ) {
  last = last || false;
  if ( data[ key ] ) {
    if ( last ) {
      sql = sql + " " + key + " = :"+ key;
    } else {
      sql = sql + " " + key + " = :"+ key + ", ";
    }
  }
  return sql;

}
const fetchRoles = async (params) => {
  let sql = 'SELECT * FROM role LIMIT :offset,:limit';
  const parameters = [
    {
      name: 'offset',
      value: { longValue: params['offset']}
    },
    {
      name: 'limit',
      value: { longValue: params['limit'] }
    }
  ];

  const result = await executeReadSql(sql, parameters)
  return result
}
const createRole = async (role_type_id, role_link_type_id, role_link_to_id, user_id, book_id) => {
  let sql = 'INSERT INTO role (role_type_id, role_link_type_id, role_link_to_id, user_id, book_id) VALUES (:role_type_id, :role_link_type_id, :role_link_to_id, :user_id, :book_id)';
  const parameters = [
    {
      name: 'role_type_id',
      value: { stringValue: role_type_id}
    },
  {
      name: 'role_link_type_id',
      value: { stringValue: role_link_type_id}
    },
{
      name: 'role_link_to_id',
      value: { longValue: role_link_to_id}
    },
{
      name: 'user_id',
      value: { longValue: user_id}
    },
    {
      name: 'book_id',
      value: { longValue: book_id }
    }

  ];


  const result = await executeWriteSql(sql, parameters)
  return result
}

const updateRole = async function(roleId, updateParams) {
  let sql = `UPDATE role SET`;
  sql = addParam( sql, updateParams, 'title' );
  sql = addParam( sql, updateParams, 'dsply_text' );
  sql = addParam( sql, updateParams, 'json_data' );
  sql = addParam( sql, updateParams, 'is_retired' );
  const parameters = [
    {
      name: 'title',
      value: { stringValue: title}
    },
    {
      name: 'dsply_text',
      value: { stringValue: dsply_text}
    },
    {
      name: 'json_data',
      value: { stringValue: json_data}
    },
    {
      name: 'is_retired',
      value: { stringValue: is_retired}
    },
    {
      name: 'role_id',
      value: { longValue: roleId}
    }

  ];

  sql = sql + " WHERE role_id = :role_id";


  const result = await executeWriteSql(sql, parameters)
  return result
}
const deleteRole = async function(roleId) {
  let sql = `DELETE role WHERE role_id = :role_id`;
  const parameters = [
    {
      name: 'role_id',
      value: { longValue: title}
    }
  ];

  const result = await executeWriteSql(sql, parameters)
  return result
}

module.exports = {
  fetchRoles,
  createRole,
  updateRole,
  deleteRole
}
