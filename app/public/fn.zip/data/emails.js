// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const {  QUESTION_TYPES, ROLE_TYPES, ROLE_LINK_TYPES } = require('../defines');
const { executeReadSql, executeWriteSql, createS3Client } = require('./utils')
const moment = require('moment');

s3 = createS3Client();

function addParam( sql, data, key, last ) {
  last = last || false;
  if ( data[ key ] ) {
    if ( last ) {
      sql = sql + " " + key + " = :"+ key;
    } else {
      sql = sql + " " + key + " = :"+ key + ", ";
    }
  }
  return sql;

}
const fetchEmail = async (email_type, locale_id) => {

  var email_template_map ={
  "purchased": "1",
  "prompt": "2",
  "prompt submitted": "3",
  "welcome": "4",
  "password reset": "5",
  "new story": "6",
  "published": "7",
  "invite": "8",
  "publish reminder": "9",
  "invite reminder": "10"
    };

		// default to english
	locale_id = locale_id || 1;
var id = email_template_map[ email_type ];
	var parameters = [

    {
      name: 'template_id',
      value: { longValue: id}
    },

    {
      name: 'locale_id',
      value: { longValue: locale_id}
    },
  ]

	console.log("looking up email: " + id);
  let sql = 'SELECT * FROM email_template WHERE email_type_id = :template_id AND locale_id = :locale_id';
  console.log("query is: " , sql);
  var results = await executeReadSql(sql, parameters);
	console.log("results are ", results);
	return results[ 0 ];
}

const storeLog = async (template_id, user_id, parent_id) => {

  var email_template_map ={
  "purchased": "1",
  "prompt": "2",
  "prompt submitted": "3",
  "welcome": "4",
  "password reset": "5",
  "new story": "6",
  "published": "7",
  "invite": "8",
  "publish reminder": "9",
  "invite reminder": "10"
    };
	var parameters = [

    {
      name: 'user_id', 
      value: { longValue: user_id}
    },

    {
      name: 'parent_id',
      value: { longValue: parent_id}
    },
  ]


  let sql = 'INSERT INTO email_log (email_template_id, user_id, parent_id) VALUES (:template_id, :user_id, :parent_id)';
  console.log("query is: " , sql);
  return await executeReadSql(sql, parameters);

}

module.exports = {
  fetchEmail,
  storeLog
}
