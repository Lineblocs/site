if (process.env['MAILER_ENV'] && process.env['MAILER_ENV'].toLowerCase()  == 'development' ) {
                email = "no_reply@anecdobio.com";
        }

