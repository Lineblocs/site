// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const { fetchRoles } = require('./roles');
const {  QUESTION_TYPES, ROLE_TYPES, ROLE_LINK_TYPES } = require('../defines');
const { executeReadSql, executeWriteSql, createS3Client } = require('./utils')
const moment = require('moment');

s3 = createS3Client();

function addParam( sql, data, key, last ) {
  last = last || false;
  if ( data[ key ] ) {
    if ( last ) {
      sql = sql + " " + key + " = :"+ key;
    } else {
      sql = sql + " " + key + " = :"+ key + ", ";
    }
  }
  return sql;

}

const fetchAllBooks = async (book_id, user_id) => {
  const parameters = [
  ]
  let sql = 'SELECT book.* FROM book ';
  console.log("query is: " , sql);
  const result = await executeReadSql(sql, parameters)
  return result;
}

const fetchBook = async (book_id, user_id) => {
  const parameters = [
    {
      name: 'book_id',
      value: { longValue: book_id}
    },
    {
      name: 'user_id',
      value: { longValue: user_id}
    }
  ]
  let sql = 'SELECT book.* FROM book ';
  //sql += ' INNER JOIN book_question_join ON book_question_join.book_id = book.book_id ';
  // user's role
  sql += ' INNER JOIN role ON role.book_id = book.book_id ';
  sql +=  'WHERE book.book_id = :book_id ';
  sql +=  'AND role.user_id = :user_id ';
  console.log("query is: " , sql);
  const result = await executeReadSql(sql, parameters)
  return result[0];
}

const fetchAnswerByQuestion = async (book_id, user_id, question_id) => {
  const parameters = [
    {
      name: 'user_id',
      value: { longValue: user_id}
    },
	{
      name: 'question_id',
      value: { longValue: question_id}
    }

  ]
  let sql = 'SELECT answers.* FROM answers ';
  sql += ' INNER JOIN book_question_join  ON book_question_join.book_question_join_id = answers.book_question_join_id ';
  sql += ' INNER JOIN question ON question.question_id = book_question_join.question_id ';
  sql +=  'WHERE question.question_id = :question_id ';
  sql +=  'AND answers.user_id = :user_id ';
  console.log("query is: " , sql);
  const result = await executeReadSql(sql, parameters)
  return result[0];
}



function calculateSendDate( results, creation_datetime, freq, index ) {
  var length = results.length-1;
  var days = freq * (index + 1);
  var time = moment(creation_datetime);
  time.add(days, 'days');
  return time.format('YYYY-MM-DD');
}

const processBookResults = async (results) => {
var promises = results.map(async (item, index) =>{
    var copy = Object.assign({}, item);
	  console.log("sent_datetime", copy.sent_datetime);
    if ( typeof copy.sent_datetime === 'boolean'  ) {
      copy['will_send_on_datetime'] = calculateSendDate( results, item.creation_datetime, parseInt(item.prompt_frequency), index );
    } else {
      copy['will_send_on_datetime'] = null;
    }
    copy['answers'] = []
    return new Promise(async (resolve,reject) => {
        var sql  = `select answers.user_id, answers.answer_id, user.first_name, user.last_name, answers.is_submitted, answers.creation_datetime, answers.answer_text, answers.json_data , answers.answer_id, count(image_id) AS image_count from answers
inner join user on user.user_id=answers.user_id
left join image on image.answer_id=answers.answer_id and image.is_retired=0
where answers.book_question_join_id= :join_id
and answers.is_retired=0
group by answers.answer_id`;
        var parameters = [
        {
          name: 'join_id',
          value: { longValue: item.book_question_join_id }
        }
      ];
      var answers = await executeReadSql(sql, parameters);
      copy['answers'] = answers.map((answer) => {
	      var copy =Object.assign({}, answer, {'question_id': item.question_id});
	      return copy;
      });

      resolve(copy);
    });
  });
  var data = await Promise.all( promises );
  return data;


}
const fetchAllBookQuestions = async () => {
  var parameters = [
  ]
  let sql = 'SELECT book.*, book_question_join.is_sent, book_question_join.sort, book_question_join.book_question_join_id, book_question_join.sent_datetime, question.* FROM book';
  sql += ' INNER JOIN book_question_join ON book_question_join.book_id = book.book_id ';
  sql += ' INNER JOIN question ON question.question_id = book_question_join.question_id ';
  sql += ' INNER JOIN role ON role.book_id = book_question_join.book_id ';
  sql += ' INNER JOIN user ON user.user_id = role.user_id ';
  sql +=  ' WHERE (book_question_join.is_retired=0)';
  sql +=  ' ORDER BY book_question_join.sort ASC';
  console.log("query is: " , sql);
  const results = await executeReadSql(sql, parameters)
  // pull answers
  var data = [];

  return await processBookResults( resuls );
}
const fetchBookUsers = async (book_id) => {
  const parameters = [
    {
      name: 'book_id',
      value: { longValue: book_id}
    }
  ]
  let sql = `SELECT * FROM (
SELECT u.first_name, u.last_name, u.email, u.user_id, r.role_id, rt.name, rlt.name as scope, r.role_link_to_id  from role r
INNER JOIN role_type rt on r.role_type_id=rt.role_type_id
INNER JOIN role_link_type rlt on rlt.role_link_type_id=r.role_link_type_id
INNER JOIN user u on u.user_id=r.user_id and u.is_retired=0
WHERE r.role_link_to_id=:book_id and r.role_link_type_id=6 and r.is_retired=0

UNION

SELECT u.first_name, u.last_name, u.email, u.user_id, r.role_id, rt.name, rlt.name as scope, r.role_link_to_id from role r
INNER JOIN role_type rt on r.role_type_id=rt.role_type_id
INNER JOIN role_link_type rlt on rlt.role_link_type_id=r.role_link_type_id
INNER JOIN user u on u.user_id=r.user_id and u.is_retired=0
INNER JOIN book_question_join bq on bq.question_id= r.role_link_to_id and bq.book_id=:book_id  and bq.is_retired=0
WHERE r.is_retired=0 and r.role_link_type_id=8
) as users
GROUP BY user_id;`;

  console.log("query is: " , sql);
  const result = await executeReadSql(sql, parameters)
  return result
}

const fetchBookQuestions = async (user_id, book_id) => {
  var parameters = [
    {
      name: 'book_id',
      value: { longValue: book_id}
    },
	{
      name: 'user_id',
      value: { longValue: user_id}
    },

  ]
  let sql = 'SELECT book.*, book_question_join.is_sent, book_question_join.sort, book_question_join.book_question_join_id, book_question_join.sent_datetime, question.* FROM book';
  sql += ' INNER JOIN book_question_join ON book_question_join.book_id = book.book_id ';
  sql += ' INNER JOIN question ON question.question_id = book_question_join.question_id ';
  sql += ' INNER JOIN role ON role.book_id = book_question_join.book_id ';
  sql += ' INNER JOIN user ON user.user_id = role.user_id ';
  sql +=  ' WHERE (book.book_id = :book_id AND book_question_join.is_retired=0)';
  sql +=  ' AND (user.user_id = :user_id) AND ((role.role_link_type_id=6 AND role.role_link_to_id=book.book_id) OR (role.role_link_type_id = 8 AND role.role_link_to_id=book_question_join.book_question_join_id)) ORDER BY book_question_join.sort ASC';
  console.log("query is: " , sql);
  const results = await executeReadSql(sql, parameters)
  // pull answers
  var data = [];

  return await processBookResults( results );
}

async function fetchBookStats(book_id)
{
  var result = {};
  var sql = `SELECT
		(count(distinct(image.image_id))+SUM(if(char_length(answers.answer_text) <860, 1, ceil((char_length(answers.answer_text) -860)/2100) +1))) as estimated_page_count,
		count(distinct(image.image_id)) as image_count,
		count(distinct(answers.answer_id)) as story_count,
		count(distinct(book_question_join.question_id)) as prompt_count
	FROM book_question_join
	LEFT JOIN answers on answers.book_question_join_id= book_question_join.book_question_join_id  and answers.is_retired=0
	LEFT JOIN image on image.answer_id=answers.answer_id and image.is_retired=0
	WHERE book_question_join.book_id = :book_id
		AND book_question_join.is_retired=0
		AND book_question_join.is_sent=1
	GROUP BY book_question_join.book_id
;`;
  const parameters = [
    {
      name: 'book_id',
      value: { longValue: book_id}
    }
  ];
  const data = await executeReadSql(sql, parameters)
  if ( data.length > 0 ) {
    return data[0];
  }
  return {
    "estimated_page_count": 0,
    "image_count": 0,
    "story_count": 0,
    "prompt_count": 0
  };
}


const fetchBooks = async (params) => {
  let sql = 'SELECT * FROM book LIMIT :offset,:limit';
  const parameters = [
    {
      name: 'offset',
      value: { longValue: params['offset']}
    },
    {
      name: 'limit',
      value: { longValue: params['limit'] }
    }
  ];

  const result = await executeReadSql(sql, parameters)
  return result
}

const fetchBooksThatRequirePublish = async (params) => {
  let sql = `select book.purchaser_user_id, book.book_id, book.title, book.start_datetime, max(product_type.dashboard_time) as dashboard_total, user.first_name, user.last_name, user.email, book.locale_id from book
inner join orders on book.book_id=orders.book_id
inner join order_line on orders.order_id=order_line.order_id
inner join product on product.product_id=order_line.product_id
inner join product_type on product_type.product_type_id=product.product_type_id
inner join user on user.user_id=book.purchaser_user_id
where book.is_published=0 and book.publish_reminder_sent=0
group by book.book_id
having (start_datetime + INTERVAL (dashboard_total -1) MONTH) <NOw()`;
  const parameters = [
  ];

  const result = await executeReadSql(sql, parameters)
  return result
}

const fetchAnswerPrompt = async (join_id, user_id) => {
  let sql = `SELECT * FROM answers WHERE book_question_join_id = :join_id AND user_id = :user_id`;
  const parameters = [
    {
      name: 'join_id',
      value: { longValue: join_id}
    },
    {
      name: 'user_id',
      value: { longValue: user_id}
    }
  ];

  const result = await executeReadSql(sql, parameters)
  return result[0];
}
const createBook = async (title, purchaser_user_id, author_user_id, json_data, is_published, is_retired, start_datetime, welcome_text) => {
  let sql = 'INSERT INTO book (title, purchaser_user_id, author_user_id, json_data, is_published, is_retired, start_datetime, welcome_text) VALUES (:title, :purchaser_user_id, :author_user_id, :json_data, :is_published, :is_retired, :start_datetime, :welcome_text)';
  const parameters = [
    {
      name: 'title',
      value: { stringValue: title}
    },
    {
      name: 'purchaser_user_id',
      value: { longValue: purchaser_user_id}
    },
    {
      name: 'author_user_id',
      value: { longValue: author_user_id}
    },

    {
      name: 'json_data',
      value: { stringValue: json_data, isNull: true}
    },
    {
      name: 'is_published',
      value: { stringValue: is_published}
    },

    {
      name: 'is_retired',
      value: { stringValue: is_retired}
    },
    {
      typeHint: 'TIMESTAMP',
      name: 'start_datetime',
      value: { stringValue: start_datetime, isNull: true}
    },
    {
      name: 'welcome_text',
      value: { stringValue: welcome_text, isNull: true}
    }
  ];


  const result = await executeWriteSql(sql, parameters)
  return result
}

const createBookQuestion = async function (book_id, text, locale) {
  var parameters = [
    {
      name: 'locale_id',
      value: { longValue: locale}
    },
    {
      name: 'question_type',
      value: { longValue: QUESTION_TYPES['CUSTOM'] }
    },
    {
      name: 'text',
      value: { stringValue: text}
    },

  ];

  // query 1
  let sql1 = `INSERT INTO question (locale_id, question_type_id, dsply_text) VALUES (:locale_id, :question_type, :text);`;

  var result = await executeWriteSql(sql1, parameters)
  console.log("result is ", result);
  var question_id = result.generatedFields[0].longValue;
  console.log("generated question ID ", question_id);

  parameters = [
    {
      name: 'book_id',
      value: { longValue: book_id}
    },
    {
      name: 'question_id',
      value: { longValue: question_id }
    }
  ];

  // query 2
  let sql2 = `INSERT INTO book_question_join
 (book_id, question_id)
VALUES
 (:book_id,:question_id)
ON DUPLICATE KEY UPDATE
 is_retired     = 0;`;

  result = await executeWriteSql(sql2, parameters)

  return {question_id};
}

const updateBook = async function(bookId, updateParams) {
  let sql = `UPDATE book SET `;

  const parameters = [
  ];

  var keys = Object.keys( updateParams );
  for ( var i = 0; i != keys.length; i ++ ) {
    var key = keys[ i ];
    var value= updateParams[ key ];
    var last = false;
    if (i === keys.length - 1) {
      last = true;
    }

    sql = addParam( sql, updateParams, key, last );
    var value = updateParams[ key ];
    parameters.push({
      "name": key,
      "value":  {
        "stringValue": value
      }
    });
  }
  sql = sql + " WHERE book_id = :book_id";
  parameters.push({
    "name": "book_id",
    "value": {
      "longValue": bookId
    }
  });

console.log("query: " + sql);
  const result = await executeWriteSql(sql, parameters)
  return result
}

const updateBookQuestion= async function(joinId, key, value) {
  let sql = `UPDATE book_question_join SET ` + key + " = :key WHERE book_question_join_id = :join_id";

  const parameters = [
    {
      "name": "key",
      "value":  {
        "stringValue": value
      }
    }, {
      "name": "join_id",
      "value":  {
        "longValue": joinId
      }
    }

  ];
  const result = await executeWriteSql(sql, parameters)
  return result
}


const fetchUserBooks = async (user_id) => {
  const parameters = [
    {
      name: 'user_id',
      value: { longValue:user_id}
    }
  ]
  let sql = `SELECT * FROM
(
	SELECT * FROM book b
	WHERE
	b.purchaser_user_id =:user_id
	OR b.author_user_id =:user_id

	UNION

	SELECT b.* from book b
	INNER JOIN role r on r.role_link_type_id=6 and r.role_link_to_id=b.book_id and r.is_retired=0
	WHERE r.user_id =:user_id

	UNION

	SELECT b.* from role r
	INNER JOIN book_question_join bq on bq.book_question_join_id= r.role_link_to_id
	INNER JOIN book b on b.book_id=bq.book_id
	WHERE r.user_id =:user_id AND r.role_link_type_id=8	and r.is_retired=0
) as books
GROUP BY book_id`;
  console.log("query is: " , sql);
  const result = await executeReadSql(sql, parameters)
  return result
}
const addQuestions = async (book_id, ids) => {

  var query = `UPDATE book_question_join SET is_retired = 1 WHERE book_id = :book_id`;
  var parameters = [
    {
      name: 'book_id',
      value: { longValue:book_id}
    }
  ];
  await executeWriteSql(query, parameters)
  // add the new records now

  if ( ids.length > 0 ) {
    ids.forEach((id, index) => {
      query = query + `(${book_id}, ${id})`
      if ( index !== ids.length - 1) {
        query =  query + `,`;
      }
    });
    var query = `INSERT INTO book_question_join
    (book_id, question_id) VALUES `;
    ids.forEach((id, index) => {
      query = query + `(${book_id}, ${id})`
      if ( index !== ids.length - 1) {
        query =  query + `,`;
      }
    });
    query = query + ` ON DUPLICATE KEY UPDATE is_retired = 0;`;
    console.log("QUERY is ", query);
    await executeWriteSql(query, []);
  }
}

const reorderQuestions = async (book_id, sort_data) => {

  for ( var index in sort_data ) {
	  var item = sort_data[ index ];
    var query = `UPDATE book_question_join SET sort = :sort WHERE book_id = :book_id AND question_id = :question_id`;
    var parameters = [
      {
        name: 'book_id',
        value: { longValue:book_id}

      },
      {
        name: 'question_id',
        value: { longValue:item.question_id}
      },
      {
        name: 'sort',
        value: { longValue:item.sort}
      }
    ];
	  console.log("sort ", parameters);
    await executeWriteSql(query, parameters)
  }
}


const updateBookUser = async function (book_id, user_id, user_role, access_type, access_list) {
  const parameters = [
    {
      name: 'book_id',
      value: { longValue:book_id}
    },
  ]
  let sql = ``;
  console.log("query is: " , sql);
  const result = await executeWriteSql(sql, parameters)
  return result
}

const answerPrompt = async function (book_id, question_id, join_id, user_id, txt, attachments) {
  var parameters = [
  {
      name: 'user_id',
      value: { longValue:user_id}
    },

    {
      name: 'join_id',
      value: { longValue:join_id}
    },
    {
      name: 'txt',
      value: { stringValue:txt}
    }
  ]
  sql = `
 INSERT INTO answers (book_question_join_id, user_id, answer_text, is_submitted) VALUES (:join_id, :user_id, :txt, 1)
ON DUPLICATE KEY UPDATE
is_submitted     = 1;
  `;
  console.log("query is: " , sql);
  var res = await executeWriteSql(sql, parameters)
  if ( res.generatedFields.length === 0 ) {
    var answer = await fetchAnswerPrompt(join_id, user_id);
    await editAnswerPrompt(book_id, question_id, answer.answer_id, user_id, txt, 1 /** is submitted */);
  }
  return res;
}

const saveAnswerDraft = async function (book_id, question_id, join_id, user_id, txt, attachments) {

  var parameters = [
  {
      name: 'user_id',
      value: { longValue:user_id}
    },

    {
      name: 'join_id',
      value: { longValue:join_id}
    },
    {
      name: 'txt',
      value: { stringValue:txt}
    }
  ]
  sql = `
 INSERT INTO answers (book_question_join_id, user_id, answer_text, is_submitted) VALUES (:join_id, :user_id, :txt, 0)
ON DUPLICATE KEY UPDATE
is_submitted     = 0;
  `;
  console.log("query is: " , sql);
  console.log("params are: " , parameters);
  var res = await executeWriteSql(sql, parameters)
  if ( res.generatedFields.length === 0 ) {
    var answer = await fetchAnswerPrompt(join_id, user_id);
    await editAnswerPrompt(book_id, question_id, answer.answer_id, user_id, txt, 0 /** is submitted */);
  }
  return res;
}


const editAnswerPrompt = async function (book_id, question_id, answer_id, user_id, txt, is_submitted) {
	if ( typeof is_submitted === 'undefined' ) {
is_submitted = 0;
	}
	console.log("is submitted ", is_submitted);
  parameters = [
    {
      name: 'id',
      value: { longValue:answer_id}
    },
    {
      name: 'txt',
      value: { stringValue:txt}
    },
    {
      name: 'is_submitted',
      value: { longValue:is_submitted}
    }

  ];
  sql = `UPDATE answers SET answer_text = :txt, is_submitted = :is_submitted WHERE answer_id = :id`;
  console.log("query is: " , sql);
  console.log("params: " , parameters);
  result = await executeWriteSql(sql, parameters)
  return result
}
const addBookRole = async function (book_id, user_id, role_type_val, link_type_val, link_to_val ) {
  var role_type = ROLE_TYPES[ role_type_val ];
  var link_type = ROLE_LINK_TYPES[ link_type_val ];
  var parameters = [
	{
      name: 'book_id',
      value: { longValue:book_id}
    },

    {
      name: 'role_type',
      value: { longValue:role_type}
    },
    {
      name: 'link_type',
      value: { longValue:link_type}
    },
    {
      name: 'link_to',
      value: { longValue:link_to_val}
    },
    {
      name: 'user_id',
      value: { longValue:user_id}
    }

  ]
  let sql = `
INSERT INTO role
(book_id, role_link_type_id, role_link_to_id, user_id, role_type_id)
VALUES
(:book_id, :link_type, :link_to, :user_id, :role_type)
ON DUPLICATE KEY UPDATE
is_retired     = 0, role_type_id = :role_type
`;
  console.log("query is: " , sql);
  var result = await executeWriteSql(sql, parameters)
  return result
}

async function removeBookUser(book_id, user_id)
{
  var result = {};
  var sql = `UPDATE role SET is_retired = 1 WHERE user_id = :user_id AND book_id = :book_id`;
  const parameters = [
    {
      name: 'user_id',
      value: { longValue: user_id}
    },
    {
      name: 'book_id',
      value: { longValue: book_id}
    },
  ];
  await executeWriteSql(sql, parameters)
}

const roleByBook = async function (book_id, user_id) {
  var sql = `SELECT u.first_name, u.last_name, u.email, u.user_id, r.role_id, rt.name, if(r.role_link_type_id=6, "book", "prompt") as scope, r.role_link_to_id  from role r
INNER JOIN role_type rt on r.role_type_id=rt.role_type_id
INNER JOIN user u on u.user_id=r.user_id
WHERE r.book_id=:book_id and u.user_id=:user_id`;
  const parameters = [
    {
      name: 'user_id',
      value: { longValue: user_id}
    },
    {
      name: 'book_id',
      value: { longValue: book_id}
    },

  ];


  const result = await executeReadSql(sql, parameters)
  return result[0];
}

const addAttachment = async( answer_id, name, caption, key_name, bucket, sort, orientation ) => {
  var parameters = [
    {
      name: 'answer_id',
      value: { longValue: answer_id}

    },
    {
      name: 'file_name',
      value: { stringValue: name}
    },
{
      name: 'key_name',
      value: { stringValue: key_name}
    },
{
      name: 'bucket_name',
      value: { stringValue: bucket}
    },
{
      name: 'caption',
      value: { stringValue: caption}
    },
{
      name: 'sort',
      value: { longValue: sort}
    },
{
      name: 'orientation',
      value: { stringValue: orientation}
    },




  ];
  var query = `INSERT INTO image (answer_id, file_name, key_name, bucket_name, caption, sort, orientation) VALUES (:answer_id, :file_name, :key_name, :bucket_name, :caption, :sort, :orientation)`;
  return await executeWriteSql(query, parameters)
}
const delAttachment = async( image_id ) => {
  var query = `UPDATE image SET is_retired = 1 WHERE  image_id = :image_id`
  var parameters = [
    {
      name: 'image_id',
      value: { longValue: image_id}

    }
  ];
  return await executeWriteSql(query, parameters)
}
const updateAnswerAttachments = async( answer_id, files) => {
  var query = `DELETE FROM image WHERE answer_id = :answer_id`
  var parameters = [
    {
      name: 'answer_id',
      value: { longValue: answer_id}

    }
  ];
  await executeWriteSql(query, parameters)

  var query = `INSERT INTO image
  (answer_id, file_name, key_name, bucket_name) VALUES `;
  files.forEach((file, index) => {
    query = query + `(${answer_id}, ${file.name}, ${file.key}, 'anecdobio')`
    if ( index !== ids.length - 1) {
      query =  query + `,`;
    }
  });
  query = query + ` ON DUPLICATE KEY UPDATE is_retired = 0;`;
  var parameters = [
  ];
  await executeWriteSql(query, parameters)
}


const removeAnswers = async (user_id, book_id, question_id) => {
  const parameters = [
    {
      name: 'user_id',
      value: { longValue: user_id}
    },

    {
      name: 'book_id',
      value: { longValue: book_id}
    }

  ]
  var sql = `DELETE FROM answer WHERE user_id = :user_id AND book_id = :book_id AND question_id = :question_id`;
  return  await executeWriteSql(sql, parameters)
}

const updateAttachment = async (image_id, data) => {
	console.log("update image="+ image_id);
	console.log("update attachment ", data);

  var query = `UPDATE image SET sort = :sort, caption = :caption WHERE image_id = :image_id`;
  var parameters = [
    {
      name: 'sort',
      value: { longValue:data.sort}
    },
    {
      name: 'caption',
      value: { stringValue:data.caption}
    },


    {
      name: 'image_id',
      value: { longValue:image_id}
    }
  ];
  return await executeWriteSql(query, parameters)
}


module.exports = {
  fetchBook,
  fetchBookStats,
  fetchBooks,
  fetchAllBooks,
  fetchAllBookQuestions,
  fetchUserBooks,
  fetchBookUsers,
  fetchBookQuestions,
  createBook,
  updateBook,
  createBookQuestion,
  addQuestions,
  removeBookUser,
  answerPrompt,
  addBookRole,
  roleByBook,
  editAnswerPrompt,
  addAttachment,
  delAttachment,
  reorderQuestions,
  saveAnswerDraft,
  removeAnswers,
  updateAttachment,
  updateBookQuestion,
fetchAnswerByQuestion,
fetchBooksThatRequirePublish
}
