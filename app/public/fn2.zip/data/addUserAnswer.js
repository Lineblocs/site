// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const { executeWriteSql } = require('./utils')


const addUserAnswer = async (answer_text, question_id, user_id) => {
  const sql = `INSERT INTO answers (answer_text, question_id, user_id) \
VALUES (:answer_text, :question_id, :user_id)`
const  parameters = [
    {
      name: 'answer_text',
      value: { stringValue: answer_text }
    },
    {
      name: 'question_id',
      value: { longValue: question_id}
    },
    {
      name: 'user_id',
      value: { longValue: user_id}
    }
  ]
  const result = await executeWriteSql(sql, parameters)
 
}

module.exports = addUserAnswer
