// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const { executeReadSql, executeWriteSql } = require('./utils')
function addParam( sql, data, key, last ) {
  last = last || false;
  if ( data[ key ] ) {
    if ( last ) {
      sql = sql + " " + key + " = :"+ key;
    } else {
      sql = sql + " " + key + " = :"+ key + ", ";
    }
  }
  return sql;

}
const fetchQuestion = async (question_id) => {
  const parameters = [
    {
      name: 'question_id',
      value: { longValue: question_id}
    }
  ]
  let sql = 'SELECT * FROM QUESTION '
 
  if(question_id !== null && question_id !== '') {
    sql +=  'WHERE question_id = :question_id'
  }
  const result = await executeReadSql(sql, parameters)
  return result
}

const fetchQuestions = async (params) => {
  let sql = 'SELECT * FROM question LIMIT :offset,:limit';
  const parameters = [
    {
      name: 'offset',
      value: { longValue: params['offset']}
    },
    {
      name: 'limit',
      value: { longValue: params['limit'] }
    }
  ];

  const result = await executeReadSql(sql, parameters)
  return result
}
const createQuestion = async (title, dsply_text, json_data, is_retired) => {
  let sql = 'INSERT INTO question (title, dsply_text, json_data, is_retired) VALUES (:title, :dsply_text, :json_data, :is_retired)';
  const parameters = [
    {
      name: 'title', 
      value: { stringValue: title}
    },
    {
      name: 'dsply_text',
      value: { stringValue: dsply_text}
    },
    {
      name: 'json_data',
      value: { stringValue: json_data}
    },
    {
      name: 'is_retired',
      value: { stringValue: is_retired} 
    }
  ];


  const result = await executeWriteSql(sql, parameters)
  return result
}

const updateQuestion = async function(questionId, updateParams) {
  let sql = `UPDATE question SET`;
  sql = addParam( sql, updateParams, 'title' );
  sql = addParam( sql, updateParams, 'dsply_text' );
  sql = addParam( sql, updateParams, 'json_data' );
  sql = addParam( sql, updateParams, 'is_retired' );
  const parameters = [
    {
      name: 'title', 
      value: { stringValue: title}
    },
    {
      name: 'dsply_text',
      value: { stringValue: dsply_text}
    },
    {
      name: 'json_data',
      value: { stringValue: json_data}
    },
    {
      name: 'is_retired',
      value: { stringValue: is_retired} 
    },
    {
      name: 'question_id',
      value: { longValue: questionId} 
    }

  ];

  sql = sql + " WHERE question_id = :question_id";


  const result = await executeWriteSql(sql, parameters)
  return result
}

module.exports = {
  fetchQuestion,
  fetchQuestions,
  createQuestion,
  updateQuestion
}