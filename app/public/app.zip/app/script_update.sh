yarn add  art \
  d3 \
  d3-shape \
  native-base \
  prop-types \
  react-native-animatable \
  react-native-calendar-datepicker \
  react-native-gifted-chat \
  react-native-scaling-drawer \
  react-native-scrollable-tab-view \
  react-native-snap-carousel \
  react-native-swipeout \
  react-navigation
