import React, { Component, useState } from 'react';
import { inject, observer } from "mobx-react";
import { Picker, TextInput, View, StyleSheet, Image, TouchableHighlight, ScrollView, StatusBar, Platform } from 'react-native';

import Text from '../elements/Text';
import Card, { Divider } from 'react-native-elements';

import GradientButton from '../elements/GradientButton';
import CheckBox from '../elements/CheckBox';
import APIService from '../helpers/api';

import { deviceWidth, deviceHeight, shadowOpt, colors } from '../styles/variables';

import CommonStyles from '../styles/CommonStyles';
import SignUpScreen from './SignUpScreen';

import ForgotPasswordScreen from './ForgotPasswordScreen';
import { reaction } from 'mobx';
//import Sound from 'react-native-sound';
import { Audio } from 'expo-av';
@inject('sampleStore')
export default class PrayerScreen extends Component {
  constructor(props) {
    super(props);
    this.props = props;
    console.log("opening new screen..");
    console.log("props ", this.props.navigation.state.params);
    this.frality_id = this.props.navigation.state.params.frality_id;
    this.frality = this.props.navigation.state.params.frality_text;
    this.api = new APIService();
    this.sound = null
    this._getPrayerData();
    this.state = {
      step: 1,
      loaded: false,
      remember: false,
      selectedValue: "Prayer Card"
    };
  }
  _getPrayerData() {
    console.log("getting prayer data..");
    this.api.getPrayer( this.frality_id, "" /** prayer type */ ).then((data) => {
      console.log("got data ", data);
      this.setState({
        prayer: data,
        loaded: true
      });
    })
  }


  async playTrack( track ) {
    console.log("playing track ", track);
    /*
    const sound = new Sound(track, null, (e) => {
      if (e) {
        console.log('error loading track:', e)
      } else {
        track.play()
      }
    })
    */
   this.sound = new Audio.Sound();

   var sound = this.sound
   await sound.loadAsync({
      uri: track,
      headers: {
      }
    }, {
      shouldPlay: false,
      volume: 1,
    })

   console.log('Playing Sound');
   sound.playAsync(); 
  }
  setSelectedValue(value) {
    this.setState({
      selectedValue: value
    });
  }
  _createCurrentScreen() {
    var step = this.state.step;
    var prayer = this.state.prayer;
    var loaded = this.state.loaded;
    console.log("creating screen..");
    if ( !loaded ) {
      return (
        <View style={[CommonStyles.buttonBox, {marginBottom: (spaceHeight * 0.005) }]}>
          <Text>Please wait..</Text>
        </View>
      );
    }
    console.log("loading step ", step);
    var data = {
      1: {
        note: prayer.purification.pur_practice_note,
        lit: prayer.purification.pur_practice_lit,
        bg1: '#E9c6aa',
        bg2: '#eb9f60',
        textcolor1: 'black',
        textcolor2: 'black',
        btncolor: ['rgb(233,198,170)','rgb(255,255,255)'], //239, 208, 185   - 233,198,170 - 255,255,255

        track: prayer.purification.track_url
      },
      2: {
        note: prayer.meditation.med_practice_note,
        lit: prayer.meditation.med_practice_lit,
        bg1: '#Bdccf7',
        bg2: '#3e66db',
        textcolor1: 'black',
        textcolor2: 'white',
        btncolor: ['rgb(189,204,247)','rgb(255,255,255)'],
        track: prayer.meditation.track_url
      },
      3: {
        note: prayer.presence.pres_practice_note,
        lit: prayer.presence.pres_practice_lit,
        bg1: '#D5c7f7',
        bg2: '#a189de',
        textcolor1: 'black',
        textcolor2: 'white',
        btncolor: ['rgb(213,199,247)','rgb(255,255,255)'],
        track: prayer.presence.track_url
      },
      4: {
        note: prayer.embodiment.emb_practice_note,
        lit: prayer.embodiment.emb_practice_lit,
        bg1: '#D3f7d2',
        bg2: '#98f796',
        textcolor1: 'black',
        textcolor2: 'black',
        btncolor: ['rgb(152,247,150)','rgb(255,255,255)'],
        track: prayer.embodiment.track_url
      }
    };
    var data2 = {
      1: "GO TO CLOISTER",
      2: "GO TO HOLY MOUNTAIN",
      3: "GO TO COMMUNITY",
      4: ""
    };

    console.log("text data ", data);
    var text = data[ parseInt(step) ];
    var btnText = data2[ parseInt(step) ];

    var btn = text['btncolor'];
    var track = text['track'];
    console.log("text is now ", text);
    const styles = {
  wrapper: {
    justifyContent: 'center',
    alignItems: 'center'
  },
}

    if ( step >= 1 && step <= 4 ) {
      var displayNext = true;
      if ( step === 4 ) {
        displayNext = false;
      }
      return (
        <>
      <View style={{height: 120}} >
        <ScrollView contentContainerStyle={{alignItems: 'center'}} style={{width: '100%',  textAlign: 'center', color: '#FFFFFF', backgroundColor: `${text['bg1']}`, border: '3px solid #ab0041'}}>
       

        <Text  style={{marginBottom: 0, fontSize: 24, textAlign: 'center', color: `${text['textcolor1']}`}}>{`${text['note']}`} </Text>
        </ScrollView>
      </View>
      
      <View style={{height: 190}} >
        <ScrollView contentContainerStyle={{alignItems: 'center'}} style={{width: '100%',  textAlign: 'center', color: '#FFFFFF', backgroundColor: `${text['bg2']}`, border: '3px solid #ab0041'}}>
          <Text  style={{marginBottom: 0, marginTop: 10, fontSize: 24, textAlign: 'center', color: `${text['textcolor2']}`}}>{`${text['lit']}`}</Text>

        
          
          </ScrollView>
      </View>

          <ScrollView contentContainerStyle={{alignItems: 'center'}} style={{width: '100%',  textAlign: 'center', color: '#000', backgroundColor: '#fff', border: '3px solid #ab0041'}}>
   
          <View  style={{marginBottom: 5}, {marginTop: 5}} contentContainerStyle={{alignItems: 'center'}}> 
              {
                displayNext && 
                  (
                  <GradientButton

                onPressButton={this._gotoCloister.bind(this)}
                setting={shadowOpt}
                background={btn}
                btnText={btnText}
                style={[CommonStyles.stackedBtn, {display: displayNext}]}
              />)
              }
              </View>
            <View style={{marginBottom: 5}, {marginTop: 5}}>
            <GradientButton
              onPressButton={this._exitPrayer.bind(this)}
              setting={shadowOpt}
              background={btn}
              btnText="EXIT PRAYER"
              style={CommonStyles.stackedBtn}
            />

            </View>
            <View style={{marginBottom: 5}, {marginTop: 5}}>
            <GradientButton
              onPressButton={() => { this.playTrack( track ); }}
              setting={shadowOpt}
              background={btn}
              btnText="PLAY BACKGROUND TRACK"

              onClick={() => { this.playTrack( track ); }}
              style={CommonStyles.stackedBtn}
            />
          </View>
          </ScrollView>
        </>
      );
    }
  }
  render() {
    return (


      <View style={CommonStyles.prayerViewerSinglePage}>


        
        <ScrollView contentContainerStyle={{height: deviceHeight - 25}}>


        <View style={styles.imageBox} contentContainerStyle={{alignItems: 'center'}}>
            <Image
source={require('../../img/healer/lab.jpg')}
              style={{width: 105, height: 105.5}} 
            />


  </View>
          <View style={styles.titleBox}>
            {/* A JSX comment */}
            {/* <Text black extraBold> Labyrinth Pilgrimage</Text> */}
          </View>
          <View style={styles.formBox}>
            <Text black extraBold extraLarge style={CommonStyles.centerText} >  Healing Prayers for: {"\n"}  - {`${this.frality}`} -   </Text>
            <View>
            </View>
          </View>
          {this._createCurrentScreen()}
        </ScrollView>
      </View>
    );
  }
  async _gotoCloister() {

    var step = this.state.step;

    var sound = this.sound

console.log("STOPPING SOUND ", sound)
    if ( sound ) {

      await sound.stopAsync()
      await sound.unloadAsync()
      
    }

    this.sound = null

    if ( step === 4 ) {
      step = 1;
    } else {
      step = step + 1;
    }
    console.log("going to next");
    this.setState({
      step: step
    });
  }
  _exitPrayer() {

    // Stop sound after Exit button pushed
    var step = this.state.step;
    var sound = this.sound

console.log("STOPPING SOUND ", sound)
   /* if ( sound ) {
      await sound.stopAsync()
      await sound.unloadAsync()
    }
    */
    this.sound = null

    // Go back to Frailty Selection
    this.props.navigation.navigate('FralitySelectionScreen');
  }
  _playBackgroundTrack(track) {
this.playTrack(track)
  }


  _goToSignUpScreen() {
    this.props.navigation.navigate('SignUpScreen');
  }

  _handleClickFortgotPass() {
    this.props.navigation.navigate('ForgotPasswordScreen');
  }
}

const ELEMENT_HEIGHT = 377;
const spaceHeight = deviceHeight - ELEMENT_HEIGHT;

const styles = StyleSheet.create({
  titleBox: {
    height: 45,
    ...Platform.select({
      ios: {
        marginTop: spaceHeight * 0.30,
        marginBottom: spaceHeight * 0.24,
      },
      android: {
        marginTop: spaceHeight * 0.030,
        marginBottom: spaceHeight * 0.020,
      },
    }),
    justifyContent: 'center',
    alignItems: 'center',
    /*
    color: '#FFFFFF', 
    backgroundColor: '#fffbad',
    //border: '3px solid #e3d800', 
    padding: '15px'
    */
  },
  formBox: {
    height: 70,
    alignItems: 'center',
    marginBottom: spaceHeight * 0.05,
  },

  imageBox: {
    height: 30,
    alignItems: 'center',
    marginBottom: spaceHeight * 0.05,
  },
  subFormBox: {
    width: deviceWidth - 85,
    height: 45,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: -10,
  },
  noteBox: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingBottom: 15,
    marginTop: -50,
  }
});


