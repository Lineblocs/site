import React, {Component} from 'react';

class APIService {

  user = null;
  token = null;
  constructor() {
  }
  makeRequest( url, method, body ) {
    var baseUrl = "http://45.77.220.252/api";
    url = baseUrl + url;
    var params = {
      method: method,
      headers: {
        Accept: 'application/json'
      }
    };
    if ( method === 'POST' || method === 'PUT' ) {
      params['headers'] = {
        'Content-Type': 'application/json'
      };
      params['body'] =  JSON.stringify(body);
    }
    
    if ( this.token !== null ) {
      params['headers']['Authorization'] = 'JWT ' + this.token;
    }
    return fetch(url, params);
  }
  login( username, password ) {
    return new Promise((resolve, reject) => {
      this.makeRequest( "/login", "POST", {"email": username, "password": password})
        .then((response) => response.json())
        .then((json) => {
          this.token =  json.token;
          this.user =  json.user;
          resolve();
        })
        .catch((error) => {
          console.error(error);
        });
      });
  }
  getFralities() {
    return new Promise((resolve, reject) => {
      this.makeRequest( "/fralities", "GET", {})
        .then((response) => response.text())
        .then((text) => {
          console.log("response ", text);
          resolve(JSON.parse( text ) );
        });
      });
  }
  getPractices() {
    return new Promise((resolve, reject) => {
      this.makeRequest( "/practices", "GET", {})
        .then((response) => response.text())
        .then((text) => {
          console.log("text is ", text);
          resolve(text);
        });
      });
  }
  getPrayer(frality_id, practice_type_id) {
    return new Promise((resolve, reject) => {
      console.log("get frality data: " + frality_id);
      var url = "/prayer?practice_id=" + practice_type_id + "&frality_id=" + frality_id;
      console.log("url is ", url);
      this.makeRequest( url, "GET", {})
        .then((response) => response.text())
        .then((text) => {
          console.log("Text ", text);
          resolve(JSON.parse(text));
        });
      });
  }

}

export default APIService;
