import React, { Component } from 'react';
import {
  Text,
  View,
  StyleSheet,
  Image,
  Platform,
  TouchableHighlight,
  TouchableOpacity,
} from 'react-native';

import { Svg } from 'expo';
import { LinearGradient } from 'expo-linear-gradient'

import { 
  colors,
  fontSize,
  fontFamily,
} from '../styles/variables';

/* var step = this.state.step;

console.log("loading step ", step); */
    var data = {
      1: {
        btnGradient1: 'rgb(233, 198, 170)',
        btnGradient2: '#eb9f60',
        btnText: 'black'
      },
      2: {
        btnGradient1: '#Bdccf7',
        btnGradient2: '#3e66db',
        btnText: 'black'
      },
      3: {
        btnGradient1: '#E9c6aa',
        btnGradient2: '#eb9f60',
        btnText: '#eb9f60'
      },
      4: {
        btnGradient1: '#E9c6aa',
        btnGradient2: '#eb9f60',
        btnText: '#eb9f60'
      }
    };
   

export default class GradientButton extends Component {
  render = () => {

    if (!this.props.background ) {
      var background = ['rgb(248, 98, 106)', 'rgb(212, 85, 91)'];
    } else {
    var background = this.props.background;
    }
    // Get the shadow settings and give them default values
    const {
      setting: {
        btnWidth = 0,
        btnHeight = 0,
        fontSize = 18,
        shadowHeight = 100,
        backgroundColor = '#f8626a',
        color = "#000",
        realColor = "#fff",
        style = {}
      },
      onPressButton,
      btnText,
    } = this.props;

    // Define button style
    const styles = StyleSheet.create({
      button: {
        width: btnWidth,
        height: btnHeight,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: btnHeight / 2,
      },
      text: {
        fontFamily: fontFamily.semiBold,
        fontSize: fontSize,
        color: '#000',
      },
    });

    // Return a view ,whose background is a svg picture
    return (
      <View>
        <View
          style={{
            width: btnWidth,
            height: shadowHeight,
            position:"absolute",
            top: -8,
            left: -15,
          }}
        >
          <Image
            source={require('../../img/healer/shadow.png')}
            style={{
              width: btnWidth + 30,
              height: (btnWidth + 30) * 145 / 660,
            }}
          />
        </View>
        
        <LinearGradient
          start={{x: 0.2, y: 0.4}} end={{x: 1.0, y: 1.0}}
          /* colors={['rgb(248, 98, 106)', 'rgb(212, 85, 91)']} */

         colors={background} 
         /* colors={['Bdccf7', '3e66db']} */
          style={[styles.button, {position: 'relative'}]}>
          <TouchableHighlight
            underlayColor={'rgb(105,105,105)'}
            style={styles.button}
            onPress={onPressButton}>
            <Text style={styles.text}>{btnText}</Text>
          </TouchableHighlight>
        </LinearGradient>
      </View>
    )
  }
}
