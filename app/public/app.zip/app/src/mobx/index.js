import  SampleStore from "./SampleStore";
// GUIDE: Import more store here
// ex:
// import UserStore from "./UserStore";

export default {
  sampleStore: new SampleStore(),
  // GUIDE: export at here
  // ex:
  // userStore: new UserStore(),
}
