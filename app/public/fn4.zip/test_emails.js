process.env["SCHEDULE_TYPE"] =  "PROMPTS";

var emailFns = require("./email_fns.js");

setImmediate(async () => {
	//await emailFns.processWelcome();
	await emailFns.processPrompts();
	//await emailFns.processPublished();
	//await emailFns.processPublishReminders();
});
