// ES Modules, e.g. transpiling with Babel
const  AmazonCognitoIdentity = require( 'amazon-cognito-identity-js' );
const { CognitoUserPool, CognitoUserAttribute, CognitoUser } = AmazonCognitoIdentity;



var poolData = {
	UserPoolId: 'eu-central-1_NNENTtHJf', // Your user pool id here
	ClientId: '4dofrnhk5fvl6et3nm9lobklj6', // Your client id here
};
var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);

var attributeList = [];
var email = '123@example.org';
var given_name = '123';
var family_name = '123';

var dataEmail = {
	Name: 'email',
	Value: email,
};

var given_name = {
	Name: 'given_name',
	Value: given_name
};
var family_name = {
	Name: 'family_name',
	Value: family_name
};
var locale = {
	Name: 'locale',
	Value: 'en-US'
};



var attributeEmail = new AmazonCognitoIdentity.CognitoUserAttribute(dataEmail);

attributeList.push(attributeEmail);
attributeList.push(given_name);
attributeList.push(family_name);
attributeList.push(locale);

userPool.signUp(email, 'tempTemp1234!@#$', attributeList, null, function(
	err,
	result
) {
	if (err) {
		console.log(err);
		return;
	}
	console.log( result );
	var cognitoUser = result.user;
	console.log('user name is ' + cognitoUser.getUsername());
	console.log(cognitoUser);
});
