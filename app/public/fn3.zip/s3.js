
const AWS = require('aws-sdk');
const fs= require('fs');
const util= require('util');
const { v4: uuidv4 } = require('uuid');

// Set the region
AWS.config.update({region: 'eu-central-1'});

// Create S3 service object
s3 = new AWS.S3({apiVersion: '2006-03-01'});
async function storeFile(name, buff, bookId, questionId)
{
  return new Promise(async function(resolve, reject) {
    // Read options from the event parameter.
    var origimage = buff;
    var id = uuidv4();
    const dstBucket = "anecdobio";
	  var re = /(?:\.([^.]+))?$/;
	var exts = re.exec(name);
	  var ext;
	  
	 if ( exts[1] ) {
		 ext = '.'+exts[1];
	 } else {
		 ext = '';
	 }

    const dstKey    = `${bookId}/${questionId}/${id}${ext}`;
    try {
        const destparams = {
            Bucket: dstBucket,
            Key: dstKey,
            Body: buff,
            ContentType: "image"
        };

        const putResult = await s3.putObject(destparams).promise(); 
        
    } catch (error) {
        console.log(error);
        reject( error );
        return;
    } 
        
    console.log('Successfully uploaded to ' + dstBucket + '/' + dstKey); 
      resolve( {
        dstKey,
        dstBucket,
        id,
        name
      });

  });
      

}

setImmediate(async function() {
  var data = fs.readFileSync('./test.jpg');
	await storeFile('test123', data);
	await storeFile('test123.jpg', data);
});

