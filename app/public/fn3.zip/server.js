// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const awsServerlessExpress = require('aws-serverless-express')
const app = require('./app')
var AWS = require('aws-sdk');


AWS.config.update({region:'eu-central-1'});
var port = 80;
app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})
