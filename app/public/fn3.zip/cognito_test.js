var handler = require('./cognito_hooks').handler;

console.log( handler );

var event = {
  "version": 1,
  "triggerSource": "CustomMessage_SignUp",
  "region": "eu-central-1",
  "userPoolId": "eu-central-1_NNENTtHJf",
  "userName": "ff5d6f8d-9498-426b-90f3-8fc3b30e3cc3",
  "callerContext": {
    "awsSdk": "",
    "clientId": ""
  },
  "request": {
    "userAttributes": {
      "phone_number_verified": false,
      "email_verified": true
    },
    "codeParameter": "####"
  },
  "response": {
    "smsMessage": "",
    "emailMessage": "",
    "emailSubject": ""
  }
};
handler( event, null, function() {
console.log('done');

});
