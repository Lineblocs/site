
const charge = async chargeData => {
  const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY)
  const { name, email, token, amount, currency, description } = chargeData

  try {
    const customer = await stripe.customers.create({
      name,
      email,
      source: token
    })

    const result = await stripe.charges.create({
      amount: amount,
      currency,
      customer: customer.id,
      description
    })
    return Promise.resolve(result)
  } catch (err) {
    return Promise.reject(err)
  }
}

module.exports = {
  charge
}
