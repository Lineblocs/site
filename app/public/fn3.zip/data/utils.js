// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const AWS = require('aws-sdk')
const { resolve } = require('path');

const moment = require('moment');
AWS.config.update({region:'eu-central-1'});
const rdsdataservice = new AWS.RDSDataService();


const parseRecords = (records, columnMetadata) => {
  // Format the results into key-value pairs with the column name and value
  const parsed = records.map((result) => {
    const obj = {}
    result.forEach((elem, idx) => {
      const columnName = columnMetadata[idx].name
      const [ columnValue, ]= Object.values(elem)
      obj[columnName] = columnValue
    })
    return obj
  })
  return parsed

}

const executeReadSql = async (sql, parameters) => {
  const params = {
    resourceArn: process.env.DATABASE_ARN,
    secretArn: process.env.SECRET_ARN,
    database: 'web',
    includeResultMetadata: true,
    sql
  }
  if (parameters) {
    params.parameters = parameters
  }
  const rawResults = await rdsdataservice.executeStatement(params).promise()
  let results = []
  if (rawResults.records) {
    results = parseRecords(rawResults.records, rawResults.columnMetadata)
  }
  return results
}

const executeWriteSql = async (sql, parameters) => {
  const params = {
    resourceArn: process.env.DATABASE_ARN,
    secretArn: process.env.SECRET_ARN,
    database: 'web',
    includeResultMetadata: true,
    sql
  }
  if (parameters) {
    params.parameters = parameters
  }
  return await rdsdataservice.executeStatement(params).promise()
}

const decodeJWT = async function(req) {
  var auth =  req.headers('Authorization');
  var splitted = auth.split(" ");
  var token = splitted[1];
  return new Promise(function(resolve, reject) {
    var pem = jwkToPem(jwk);
    jwt.verify(token, pem, function(err, decoded) {
      resolve( decoded );
    }, function(err) {
      reject( err );
    });
  });
}

async function estimatePages(book)
{
  return new Promise((resolve, reject) => {
    resolve(0);
  })
}

function createS3Client() {
  // Set the region
  AWS.config.update({region: 'eu-central-1'});

  // Create S3 service object
  s3 = new AWS.S3({apiVersion: '2006-03-01'});
  return s3;

}
function createSESClient() {
  // Set the region
  AWS.config.update({region: 'eu-west-1'});

  // Create S3 service object
  var ses = new AWS.SES({apiVersion: '2010-12-01'});
  return ses;

}

async function signedURL( key ) {
s3 = createS3Client();
    var myBucket= "aws-s3-cors-s3uploadbucket-eacw8g4n2pp3";
    var signedUrlExpireSeconds = 3600 * 1; //1 hour

    const url = await s3.getSignedUrl('getObject', {
        Bucket: myBucket,
        Key: key,
        Expires: signedUrlExpireSeconds
    });
    return Promise.resolve( url );
}
function replaceTemplatePlaceholders( content, replacements ) 
{
  for ( var index in replacements ) {
    var value = replacements[ index ];
	console.log("index ", index);
	console.log("replacing ", value);
    //var reg = new RegExp("\\{" + index + "\\}");
    var reg = new RegExp("###" + index + "###", "g");
    content = content.replace( reg, value );
  }

  return content; 
}
async function createEmailTemplate(type, locale_id, replacements)
{
  return new Promise(async (resolve, reject) => {
    var email =await fetchEmail(type, locale_id);
    var subject = email.subject;
    var body = email.body;
    body = replaceTemplatePlaceholders( body );

    return resolve({
      body: body,
      subject: subject
    });
  });
}

async function sendEmail( email, subject, body  )
{
var ses = createSESClient();
	var from = 'bounce@bounce.anecdobio.com';
	        //debugging only..
        if (process.env['MAILER_ENV'] && process.env['MAILER_ENV'].toLowerCase()  == 'development' ) {
                email = "no_reply@anecdobio.com";
        }
  var params = {

    Destination: {
      ToAddresses: [email],
    },
    Message: {
      Body: {
        Text: {
          Charset: "UTF-8",
          Data: body
        },
        Html: {
          Charset: "UTF-8",
          Data: body
        },
      },

      Subject: {
        Charset: "UTF-8",
        Data: subject
      },
    },
    Source: from
  };

  return ses.sendEmail(params).promise();

}
async function sendEmailAndProcessReplacements(type, email, replacements)
{
  var from = "bounce@bounce.anecdobio.com";
  var {body,subject} = await createEmailTemplate( type, replacements );
  return await sendEmail( email, subject, body );
}
function calculateSendDate( results, creation_datetime, freq, index ) {
  var length = results.length-1;
  var days = freq * (index + 1);
  var time = moment(creation_datetime);
  time.add(days, 'days');
  return time;
}
module.exports = {
  executeReadSql,
  executeWriteSql,
  decodeJWT,
  createS3Client,
  createSESClient,
	signedURL,
  createEmailTemplate,
  replaceTemplatePlaceholders,
  sendEmail,
  sendEmailAndProcessReplacements,
  calculateSendDate
}
