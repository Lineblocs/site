// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const { executeReadSql, executeWriteSql } = require('./utils')

function addParam( sql, data, key, last ) {
  last = last || false;
  if ( data[ key ] ) {
    if ( last ) {
      sql = sql + " " + key + " = :"+ key;
    } else {
      sql = sql + " " + key + " = :"+ key + ", ";
    }
  }
  return sql;

}
const fetchBook = async (user_id, book_id) => {
  const parameters = [
    {
      name: 'book_id',
      value: { longValue: book_id}
    },
    {
      name: 'user_id',
      value: { longValue: user_id}
    }
  ]
  let sql = 'SELECT book.* FROM book';
  sql += ' INNER JOIN book_question_join ON book_question_join.book_id = book.book_id ';
  // user's role
  sql += ' INNER JOIN role ON role.book_id = book.book_id ';
  sql +=  'WHERE book.book_id = :book_id ';
  sql +=  'WHERE role.user_id = :user_id ';
  console.log("query is: " , sql);
  const result = await executeReadSql(sql, parameters)
  return result
}

const fetchBookQuestions = async (book_id) => {
  const parameters = [
    {
      name: 'book_id',
      value: { longValue: book_id}
    }
  ]
  let sql = 'SELECT book.* FROM book';
  sql += ' INNER JOIN book_question_join ON book_question_join.book_id = book.book_id ';
  sql += ' INNER JOIN question ON question.book_id = book.book_id ';
  sql +=  'WHERE book.book_id = :book_id ';
  console.log("query is: " , sql);
  const result = await executeReadSql(sql, parameters)
  return result
}
const fetchBookUsers = async (book_id) => {
  const parameters = [
    {
      name: 'book_id',
      value: { longValue: book_id}
    }
  ]
  let sql = 'SELECT book.* FROM book';
  sql += ' INNER JOIN book_question_join ON book_question_join.book_id = book.book_id ';
  // user's role
  sql += ' INNER JOIN role ON role.book_id = book.book_id ';
  sql +=  'WHERE book.book_id = :book_id ';
  console.log("query is: " , sql);
  const result = await executeReadSql(sql, parameters)
  return result
}





function fetchBookStats(book_id)
{
  var result = {};
  var sql = `SELECT					
		(count(distinct(image.image_id))+SUM(if(char_length(answers.answer_text) <860, 1, ceil((char_length(answers.answer_text) -860)/2100) +1))) as estimated_page_count,			
		count(distinct(image.image_id)) as image_count,			
		count(distinct(answers.answer_id)) as story_count,			
		count(distinct(book_question_join.question_id)) as prompt_count			
	FROM book_question_join				
	LEFT JOIN answers on answers.book_question_join_id= book_question_join.book_question_join_id  and answers.is_retired=0				
	LEFT JOIN image on image.answer_id=answers.answer_id and image.is_retired=0				
	WHERE book_question_join.book_id = :book_id			
		AND book_question_join.is_retired=0			
		AND book_question_join.is_sent=1			
	GROUP BY book_question_join.book_id				
;`;
  const parameters = [
    {
      name: 'book_id',
      value: { longValue: book_id}
    }
  ];
  const data = await executeReadSql(sql, parameters)
  return data[0];
}


const fetchBooks = async (params) => {
  let sql = 'SELECT * FROM book LIMIT :offset,:limit';
  const parameters = [kkkkkkkkkkkkk
    {
      name: 'offset',
      value: { longValue: params['offset']}
    },
    {
      name: 'limit',
      value: { longValue: params['limit'] }
    }
  ];

  const result = await executeReadSql(sql, parameters)
  return result
}
const createBook = async (title, purchaser_user_id, author_user_id, json_data, is_published, is_retired) => {
  let sql = 'INSERT INTO book (title, purchaser_user_id, author_user_id, json_data, is_published, is_retired) VALUES (:title, :purchaser_user_id, :author_user_id, :json_data, :is_published, :is_retired)';
  const parameters = [
    {
      name: 'title', 
      value: { stringValue: title}
    },
    {
      name: 'purchaser_user_id',
      value: { longValue: purchaser_user_id}
    },
    {
      name: 'author_user_id',
      value: { longValue: author_user_id}
    },

    {
      name: 'json_data',
      value: { stringValue: json_data}
    },
    {
      name: 'is_published',
      value: { stringValue: is_published} 
    },

    {
      name: 'is_retired',
      value: { stringValue: is_retired} 
    }
  ];


  const result = await executeWriteSql(sql, parameters)
  return result
}

const createBookQuestion = async (book_id, question_id) {
  let sql = `INSERT INTO book_question_join
(book_id, question_id)
VALUES
(:book_id,:question_id)
ON DUPLICATE KEY UPDATE
  is_retired     = 0;`;
  const parameters = [
    {
      name: 'book_id', 
      value: { longValue: book_id}
    },
    {
      name: 'question_id',
      value: { longValue: question_id}
    }
  ];


  const result = await executeWriteSql(sql, parameters)
  return result
}

const updateBook = async function(bookId, updateParams) {
  let sql = `UPDATE book SET`;
  sql = addParam( sql, updateParams, 'title' );
  sql = addParam( sql, updateParams, 'dsply_text' );
  sql = addParam( sql, updateParams, 'json_data' );
  sql = addParam( sql, updateParams, 'is_retired' );
  const parameters = [
    {
      name: 'title', 
      value: { stringValue: title}
    },
    {
      name: 'dsply_text',
      value: { stringValue: dsply_text}
    },
    {
      name: 'json_data',
      value: { stringValue: json_data}
    },
    {
      name: 'is_retired',
      value: { stringValue: is_retired} 
    },
    {
      name: 'book_id',
      value: { longValue: bookId} 
    }

  ];

  sql = sql + " WHERE book_id = :book_id";


  const result = await executeWriteSql(sql, parameters)
  return result
}

const fetchUserBooks = async (user_id) => {
  const parameters = [
    {
      name: 'user_id',
      value: { longValue:user_id}
    }
  ]
  let sql = `SELECT * FROM					
(					
	SELECT * FROM book b				
	WHERE				
	b.purchaser_user_id =:user_id				
	OR b.author_user_id =:user_id				
					
	UNION				
					
	SELECT b.* from book b				
	INNER JOIN role r on r.role_link_type_id=6 and r.role_link_to_id=b.book_id				
	WHERE r.user_id =:user_id				
					
	UNION				
					
	SELECT b.* from role r				
	INNER JOIN book_question_join bq on bq.question_id= r.role_id				
	INNER JOIN book b on b.book_id=bq.book_id				
	WHERE r.user_id =:user_id AND r.role_link_type_id=8				
) as books					
GROUP BY book_id`;
  console.log("query is: " , sql);
  const result = await executeReadSql(sql, parameters)
  return result
}

const createBookQuestion = async (book_id, text) => {
  const parameters = [
    {
      name: 'book_id',
      value: { longValue:book_id}
    },
    {
      name: 'text',
      value: { stringValue:text}
    }
  ]
  let sql = ``;
  console.log("query is: " , sql);
  const result = await executeWriteSql(sql, parameters)
  return result
}
const addQuestions = async (book_id, text) => {
  const parameters = [
    {
      name: 'book_id',
      value: { longValue:book_id}
    },
    {
      name: 'text',
      value: { stringValue:text}
    }
  ]
  let sql = ``;
  console.log("query is: " , sql);
  const result = await executeWriteSql(sql, parameters)
  return result
}
module.exports = {
  fetchBook,
  fetchBookStats,
  fetchBooks,
  fetchUserBooks,
  fetchBookUsers,
  fetchBookQuestions,
  createBook,
  updateBook,
  createBookQuestion,
  addQuestions
}