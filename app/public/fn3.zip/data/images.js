// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const { executeReadSql } = require('./utils')

function addParam( sql, data, key, last ) {
  last = last || false;
  if ( data[ key ] ) {
    if ( last ) {
      sql = sql + " " + key + " = :"+ key;
    } else {
      sql = sql + " " + key + " = :"+ key + ", ";
    }
  }
  return sql;

}
const fetchImages = async (params) => {
  let sql = 'SELECT * FROM image LIMIT :offset,:limit';
  const parameters = [
    {
      name: 'offset',
      value: { longValue: params['offset']}
    },
    {
      name: 'limit',
      value: { longValue: params['limit'] }
    }
  ];

  const result = await executeReadSql(sql, parameters)
  return result
}
const createImage = async (answer_id, filename, caption, bucket_name, author_user_id) => {
  let sql = 'INSERT INTO image (answer_id, filename, caption, bucket_name, author_user_id) VALUES (:answer_id, :filename, :caption, :bucket_name, :author_user_id)';

  const parameters = [
  {
      name: 'answer_id', 
      value: { longValue:answer_id} 
    },

    {
      name: 'file_name', 
      value: { stringValue: file_name}
    },
  {
      name: 'caption', 
      value: { stringValue: caption}
    },
{
      name: 'bucket_name', 
      value: { stringValue: bucket_name}
    },
{
      name: 'author_user_id', 
      value: { stringValue: author_user_id}
    },


  ];


  const result = await executeWriteSql(sql, parameters)
  return result
}

const updateImage = async function(imageId, updateParams) {
  let sql = `UPDATE image SET`;
  sql = addParam( sql, updateParams, 'title' );
  sql = addParam( sql, updateParams, 'dsply_text' );
  sql = addParam( sql, updateParams, 'json_data' );
  sql = addParam( sql, updateParams, 'is_retired' );
  const parameters = [
    {
      name: 'title', 
      value: { stringValue: title}
    },
    {
      name: 'dsply_text',
      value: { stringValue: dsply_text}
    },
    {
      name: 'json_data',
      value: { stringValue: json_data}
    },
    {
      name: 'is_retired',
      value: { stringValue: is_retired} 
    },
    {
      name: 'image_id',
      value: { longValue: imageId} 
    }

  ];

  sql = sql + " WHERE image_id = :image_id";


  const result = await executeWriteSql(sql, parameters)
  return result
}
const deleteImage = async function(imageId) {
  let sql = `DELETE image WHERE image_id = :image_id`;
  const parameters = [
    {
      name: 'image_id', 
      value: { longValue: title}
    }
  ];

  const result = await executeWriteSql(sql, parameters)
  return result
}

module.exports = {
  fetchImages,
  createImage,
  updateImage,
  deleteImage
}