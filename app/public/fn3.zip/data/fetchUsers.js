// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
const { executeReadSql } = require('./utils')

const fetchUsers = async () => {
  const parameters = [
  ];
  const sql = 'SELECT * FROM USER';
  const result = await executeReadSql(sql, parameters)
  return result
}

module.exports = fetchUsers