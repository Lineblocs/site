const { executeReadSql, executeWriteSql } = require('./utils')

const createOrder = async data => {
	const { user_id, shipping_address_id, billing_address_id, book_id, total, tax_total } = data

	const sql = `INSERT INTO orders (user_id, shipping_address_id, billing_address_id, book_id, total, tax_total) VALUES (:user_id, :shipping_address_id, :billing_address_id, :book_id, :total, :tax_total)`
	const  parameters = [
    {
      name: 'user_id',
      value: { longValue: user_id },
    },
    {
      name: 'shipping_address_id',
      value: { longValue: shipping_address_id}
    },
    {
      name: 'billing_address_id',
      value: { longValue: billing_address_id }
    },
    {
      name: 'book_id',
      value: { longValue: book_id}
    },
    {
      name: 'total',
      value: { longValue: total}
    },
		{
      name: 'tax_total',
      value: { longValue: tax_total}
    }
  ]

	try {
		const result = await executeWriteSql(sql, parameters)
		return Promise.resolve(result)
	} catch (error) {
		return Promise.reject(error)
	}
}

module.exports = {
  createOrder
};
