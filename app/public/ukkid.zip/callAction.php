<?php

require_once(__DIR__."/bootstrap.php");
$twiml = new Twilio\Twiml();
$sid = $_REQUEST['CallSid'];
$path = implode(DIRECTORY_SEPARATOR, array(__DIR__, "sids", $sid));
if (file_put_contents($path, "ended") == FALSE) {
  echo "error occured..";
}
$twiml->hangup();
echo $twiml;
