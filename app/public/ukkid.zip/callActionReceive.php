<?php

require_once(__DIR__."/bootstrap.php");
$twiml = new Twilio\Twiml();
$sid = $_REQUEST['CallSid'];
$twiml->hangup();
echo $twiml;
