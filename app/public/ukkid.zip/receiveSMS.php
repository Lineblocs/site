<?php
require_once(__DIR__."/bootstrap.php");

use Twilio\Rest\Client;
use Twilio\TwiML\MessagingResponse;
$twilio = new Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);

//$from = $_REQUEST['From'];
$from = "+13037488740";
$body= @$_REQUEST['Body'];

$currentRow = 2;
$range = 'MAIN!A2:T';
$rows = $sheets->spreadsheets_values->get($spreadsheetId, $range, ['majorDimension' => 'ROWS']);

if (!isset($rows['values'])) {
  die("no values found in spreadhseet");
}
foreach ($rows['values'] as $row) {
  if (empty($row[0])) {
        break;
  }

  $date = checkRowForEmpty($row, 0);
  $name = checkRowForEmpty($row, 1);
  $invoice_id = checkRowForEmpty($row, 2);
  $location= checkRowForEmpty($row, 4);
  $phone_no = checkRowForEmpty($row, 5);

  $status = checkRowForEmpty($row, 8);
  $numberStr = $phone_no;
  $phoneUtil = \libphonenumber\PhoneNumberUtil::getInstance();
    try {
        $numberProto = $phoneUtil->parse($numberStr, "US");
        $formatted = $phoneUtil->format($numberProto, \libphonenumber\PhoneNumberFormat::E164);
	//printf("Comparing number %s to %s", $from, $formatted);
        if ( $formatted == $from ) {
               $body = sprintf("Order status is %s", $status) ;
                $response = new MessagingResponse();
                $response->message($body);

                echo $response;
                exit( 0 );
        }
    } catch (\libphonenumber\NumberParseException $e) {
        continue;
    }
}

$response = new MessagingResponse();
$response->message('Auto reply text..');

echo $response;

exit( 0 );
