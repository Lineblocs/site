<?php
require_once(__DIR__."/bootstrap.php");

use Twilio\Rest\Client;

$twilio = new Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
$currentRow = 2;
$range = 'MAIN!A:T';
//$range = 'DUSTING!A:T';
//$range = '1124070518!A:T';

$rows = $sheets->spreadsheets_values->get($spreadsheetId, $range, ['majorDimension' => 'ROWS']);

if (!isset($rows['values'])) {
  die("no values found in spreadhseet");
}
foreach ($rows['values'] as $cnt => $row) {
  if (empty($row[0])) {
        break;
  }
  $row_count = $cnt + 2; // 2 because we start from 0 and we need to skip header
  $now = new \DateTime();
  $date = checkRowForEmpty($row, 0);
  $name = checkRowForEmpty($row, 1);
  $invoice_id = checkRowForEmpty($row, 2);
  $location= checkRowForEmpty($row, 4);
  $phone_no = checkRowForEmpty($row, 5);

  $status = checkRowForEmpty($row, 8);
  $a_sms_sent = checkRowForEmpty($row, 9);
  $d_sms_sent = checkRowForEmpty($row, 10);

  echo var_dump( $row  );
  echo var_dump($a_sms_sent);
  echo var_dump($d_sms_sent);
  if ( $status == 'ACOMA READY' && ($a_sms_sent == 'N' || empty( $a_sms_sent )))
  {
    $body = sprintf("Hi %s,
This is an automated message from Oriental Rug & Carpet Clinic to let you know your rug work order #%s is ready for pickup at our Main location: https://g.page/RugClinic?share

If you have any questions, you can call/text us at 720-998-8877
Thanks", $invoice_id, $name);

	printf("Sending SMS to %s. Contents: %s\r\n",$phone_no, $body);
    sendSMS(TWILIO_NUMBER, $phone_no, $body);
    updateSheet($sheets, $spreadsheetId, "J", $row_count, "Y");
  }

  if ( $status == 'Dropped off Locations' && ($d_sms_sent == 'N' || empty( $d_sms_sent )))
  {
    sprintf("Hi %s
This is an automated message from Oriental Rug & Carpet Clinic. Your rug work order #%s is ready for pickup at the %s location.

If you have any questions you can call/text us at 720.998.8877

Thank you.", $invoice_id, $name, $location);
	printf("Sending SMS to %s. Contents: %s\r\n",$phone_no, $body);

    sendSMS(TWILIO_NUMBER, $phone_no, $body);
    updateSheet($sheets, $spreadsheetId, "K", $row_count, "Y");
  }
}

