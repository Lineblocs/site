<?php

use Twilio\Rest\Client;

function findRowNumberInSpreadsheet($sheets, $spreadsheetId, $target)
{
  $range = 'A2:E1000';
  $rows = $sheets->spreadsheets_values->get($spreadsheetId, $range, ['majorDimension' => 'ROWS']);
  if (!isset($rows['values'])) {
    die("no values found in spreadhseet");
  }
  foreach ($rows['values'] as $cnt => $row) {
    if (empty($row[0])) {
          break;
    }
    $number = $row[0];
    if ($number == $target) {
      return $cnt;
    }
  }
}
function updateSheet($sheets, $spreadsheetId, $col, $row, $value)
{
  echo "updateSheet called " .PHP_EOL;
  $updateRange = $col.$row;
  echo "updating range: " .$updateRange . " value: " .$value .PHP_EOL;
  $updateBody = new \Google_Service_Sheets_ValueRange([
      'range' => $updateRange,
      'majorDimension' => 'ROWS',
      'values' => ['values' => $value]
  ]);
  $sheets->spreadsheets_values->update(
      $spreadsheetId,
      $updateRange,
      $updateBody,
      ['valueInputOption' => 'USER_ENTERED']
  );

}
function checkRowForEmpty($row, $index)
{
  if (!isset($row[$index]) || (isset($row[$index]) && $row[$index] == "")) {
    return NULL;
  }
  return $row[$index];
}
function sendSMS($from, $to, $body) {
	try {
$twilio = new Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
$message = $twilio->messages
                      ->create($to,
                              ["body" => $body,  "from" => $from]
                      );
return $message;
	} catch (\Exception $ex) {
		print($ex->getMessage());
	}
}



