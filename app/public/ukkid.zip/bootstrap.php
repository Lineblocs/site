<?php
//ini_set("display_errors", "On");
//error_reporting(E_ALL);
date_default_timezone_set("America/Chicago");
require_once(__DIR__."/config.php");
require_once(__DIR__."/vendor/autoload.php");
use Twilio\Rest\Client;
$client = new Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);

/*
 * We need to get a Google_Client object first to handle auth and api calls, etc.
 */
$google = new \Google_Client();
$google->setApplicationName('My PHP App');
$google->setScopes([\Google_Service_Sheets::SPREADSHEETS]);
$google->setAccessType('offline');

/*
 * The JSON auth file can be provided to the Google Client in two ways, one is as a string which is assumed to be the
 * path to the json file. This is a nice way to keep the creds out of the environment.
 *
 * The second option is as an array. For this example I'll pull the JSON from an environment variable, decode it, and
 * pass along.
 */
//$jsonAuth = getenv('JSON_AUTH');
$jsonAuth = json_decode( file_get_contents(__DIR__."/auth/service-account.json"), TRUE );
$google->setAuthConfig($jsonAuth);

/*
 * With the Google_Client we can get a Google_Service_Sheets service object to interact with sheets
 */
$sheets = new \Google_Service_Sheets($google);
//$spreadsheetId = "1HdJZZKAerPnPjA9elNTcqp6l3PEZaycY88UBvAAQ1DY";
$spreadsheetId = "1195oHOHY04NcyE6vbwHg8lHvn1FQxRXC0ea6TTert64";

function create_url($path, $params=NULL) {
  if (is_null($params)) {
    return implode("/",array(BASE_URL, $path));
  }
  $query = "?". http_build_query($params);
  return implode("/",array(BASE_URL, $path)).$query;

}
function debug_call_status($call) {
  printf("Call SID %s, status %s\r\n", $call->sid, $call->status);
}

require_once(__DIR__."/functions.php");

