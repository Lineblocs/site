
import json
import os
from simple_salesforce import Salesforce




# AssignmentAccepted: A worker has accepted a HIT and has an assignment.
# 
# AssignmentAbandoned: An assignment has been abandoned because the assignment duration has elapsed.
# 
# AssignmentReturned: A worker has chosen to return an assignment rather than complete the task.
# 
# AssignmentSubmitted: A worker has submitted an assignment.
# 
# AssignmentRejected: You have rejected an assignment.
# 
# AssignmentApproved: An assignment has been approved.
# 
# HITCreated: A HIT has been created using the HIT Type.
# 
# HITExtended: Assignments have been added to a HIT.
# 
# HITDisposed: A HIT has been disposed.
# 
# HITReviewable: A HIT has reached the Reviewable state, either because all of the assignments have been submitted or the HIT has expired.
# 
# HITExpired: The HIT has expired (the lifetime has elapsed) before all of the available assignments have been submitted.
# 
# Ping: Is only be sent when using the SendTestEventNotification operation.

def create_sf():

    credentials = {
        'username': os.getenv('SF_USERNAME'),
        'password': os.getenv('SF_PASSWORD'),
        'security_token': os.getenv('SF_SECURITYTOKEN'),
         'instance_url': os.getenv('SF_INSTANCEURL')
    }
    sf = Salesforce(username = credentials['username'], password = credentials['password'],\
                                 security_token = credentials['security_token'],
                                 instance_url=credentials['instance_url']
                                 )

## get the status of the HIT
def parse_notif( event ):
    results = []
    if 'Events' in event.keys():
        doc_id = event['EventDocId']
        customer_id = event['CustomerId']
        for item in event['Events']:
    
            group_id = item['HITGroupId']
            event_type = item['EventType']
            if event_type == 'AssignmentAccepted':
                status = 'done'
            elif event_type == 'AssignmentAbandoned':
                status = 'done'
            elif event_type == 'AssignmentReturned':
                status = 'done'
            elif event_type == 'AssignmentSubmitted':
                status = 'done'
            elif event_type == 'AssignmentApproved':
                status = 'done'
            results.append( {
                'id': group_id,
                'status': event_type,
                'doc_id': doc_id,
                'customer_id': customer_id
            })
            
    return results
    
    
def update_task( id, status ):
    query = "UPDATE Task SET status = '" + status + "' WHERE Id = '" + id + "'"
    sf = create_sf()
    sf.bulk.Account.query_all(query)
    

def lambda_handler(event, context):

    notifs = parse_notif( event )
    if len( notifs ) > 0:
        for notif in notifs:
            id = notif['doc_id']
            status = notif['status']
            update_task( id, status )
        
    return {
        'statusCode': 200,
        'body': json.dumps({'status': 'OK', 'msg': 'SF events were processed successfully..'})
    }